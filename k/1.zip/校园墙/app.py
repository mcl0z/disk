from flask import Flask, request, jsonify, render_template, make_response
import json
import os
import uuid
from datetime import datetime

app = Flask(__name__)

# 数据文件路径
TAGS_FILE = 'data/tags.json'

# 初始化数据文件
def init_data_file():
    if not os.path.exists('data'):
        os.makedirs('data')
    if not os.path.exists(TAGS_FILE):
        with open(TAGS_FILE, 'w', encoding='utf-8') as f:
            json.dump([], f, ensure_ascii=False, indent=2)

# 加载标签数据
def load_tags():
    try:
        with open(TAGS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

# 保存标签数据
def save_tags(tags):
    with open(TAGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(tags, f, ensure_ascii=False, indent=2)

# 生成或获取用户ID
def get_user_id():
    user_id = request.cookies.get('user_id')
    if not user_id:
        user_id = str(uuid.uuid4())
    return user_id

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/user', methods=['GET', 'POST'])
def user_info():
    user_id = get_user_id()
    response = make_response(jsonify({'user_id': user_id}))
    
    if request.method == 'POST' or not request.cookies.get('user_id'):
        response.set_cookie('user_id', user_id, max_age=31536000)  # 1年有效期
        response.set_cookie('steps', '10', max_age=31536000)  # 初始步数
    
    return response

@app.route('/api/tags', methods=['GET'])
def get_tags():
    tags = load_tags()
    return jsonify(tags)

@app.route('/api/tags', methods=['POST'])
def create_tag():
    data = request.get_json()
    
    # 检查用户步数
    user_steps = int(request.cookies.get('steps', '0'))
    if user_steps <= 0:
        return jsonify({'error': '步数不足'}), 400
    
    # 创建新标签
    new_tag = {
        'id': str(uuid.uuid4()),
        'text': data.get('text', '')[:20],  # 限制20字符
        'color': data.get('color', '#ffeb3b'),
        'x': data.get('x', 0),
        'y': data.get('y', 0),
        'rotation': data.get('rotation', 0),
        'creator': get_user_id(),
        'nails': 1,  # 默认1个钉子
        'created_at': datetime.now().isoformat(),
        'last_action': 'create'
    }
    
    tags = load_tags()
    tags.append(new_tag)
    save_tags(tags)
    
    # 扣除步数
    new_steps = user_steps - 1
    response = make_response(jsonify(new_tag))
    response.set_cookie('steps', str(new_steps), max_age=31536000)
    
    return response

@app.route('/api/tags/<tag_id>', methods=['PUT'])
def update_tag(tag_id):
    data = request.get_json()
    user_id = get_user_id()
    user_steps = int(request.cookies.get('steps', '0'))
    
    if user_steps <= 0:
        return jsonify({'error': '步数不足'}), 400
    
    tags = load_tags()
    tag_index = -1
    for i, tag in enumerate(tags):
        if tag['id'] == tag_id:
            tag_index = i
            break
    
    if tag_index == -1:
        return jsonify({'error': '标签不存在'}), 404
    
    tag = tags[tag_index]
    
    # 检查是否是创建者
    if tag['creator'] != user_id:
        return jsonify({'error': '只能操作自己创建的标签'}), 403
    
    # 步数逻辑：装钉子+1，拆钉子-1，但如果是装上再拆或拆下再装，步数回归1
    action = data.get('action', '')
    nails_change = 0
    
    if action == 'add_nail':
        nails_change = 1
        tag['last_action'] = 'add'
    elif action == 'remove_nail':
        nails_change = -1
        tag['last_action'] = 'remove'
    
    new_nails = tag['nails'] + nails_change
    
    # 钉子归零则删除标签
    if new_nails <= 0:
        tags.pop(tag_index)
        save_tags(tags)
        response = make_response(jsonify({'deleted': True}))
        response.set_cookie('steps', str(user_steps - 1), max_age=31536000)
        return response
    
    # 步数逻辑：装拆+1，但如果是装上再拆或拆下再装，步数回归1
    if action == 'add_nail' and tag['last_action'] == 'remove':
        new_steps = user_steps + 1  # 回归步数
    elif action == 'remove_nail' and tag['last_action'] == 'add':
        new_steps = user_steps + 1  # 回归步数
    else:
        new_steps = user_steps - 1  # 正常扣除步数
    
    tag['nails'] = new_nails
    save_tags(tags)
    
    response = make_response(jsonify(tag))
    response.set_cookie('steps', str(new_steps), max_age=31536000)
    
    return response

if __name__ == '__main__':
    init_data_file()
    app.run(debug=True, host='0.0.0.0', port=5100)