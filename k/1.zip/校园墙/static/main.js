class WallSystem {
    constructor() {
        this.canvas = document.getElementById('wall-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.tags = [];
        this.userId = null;
        this.userSteps = 0;
        this.selectedColor = '#ffeb3b';
        this.isCreatingTag = false;
        this.pendingTag = null;
        
        // 墙面参数
        this.wallWidth = 3000;
        this.wallHeight = 2000;
        this.viewX = 0;
        this.viewY = 0;
        this.scale = 1;
        this.minScale = 0.1;
        this.maxScale = 3.0;
        
        // 拖拽状态
        this.isDragging = false;
        this.lastMouseX = 0;
        this.lastMouseY = 0;
        
        // 缩放相关
        this.isScaling = false;
        this.touchStartDistance = 0;
        this.scaleStart = 1;
        
        this.init();
    }
    
    async init() {
        await this.loadUserInfo();
        await this.loadTags();
        this.setupEventListeners();
        this.resizeCanvas();
        this.render();
        
        window.addEventListener('resize', () => this.resizeCanvas());
    }
    
    async loadUserInfo() {
        try {
            const response = await fetch('/api/user');
            const data = await response.json();
            this.userId = data.user_id;
            this.userSteps = parseInt(document.cookie.split('; ').find(row => row.startsWith('steps='))?.split('=')[1] || '0');
            this.updateUI();
        } catch (error) {
            console.error('加载用户信息失败:', error);
        }
    }
    
    async loadTags() {
        try {
            const response = await fetch('/api/tags');
            this.tags = await response.json();
            this.render();
        } catch (error) {
            console.error('加载标签失败:', error);
        }
    }
    
    setupEventListeners() {
        // 鼠标事件
        this.canvas.addEventListener('mousedown', (e) => this.handleMouseDown(e));
        this.canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        this.canvas.addEventListener('mouseup', (e) => this.handleMouseUp(e));
        this.canvas.addEventListener('click', (e) => this.handleCanvasClick(e));
        
        // 鼠标滚轮缩放
        this.canvas.addEventListener('wheel', (e) => this.handleMouseWheel(e));
        
        // 触摸事件（移动端支持）
        this.canvas.addEventListener('touchstart', (e) => this.handleTouchStart(e));
        this.canvas.addEventListener('touchmove', (e) => this.handleTouchMove(e));
        this.canvas.addEventListener('touchend', (e) => this.handleTouchEnd(e));
        
        // 控件事件
        document.getElementById('color-picker').addEventListener('change', (e) => {
            this.selectedColor = e.target.value;
        });
        
        document.getElementById('create-tag-btn').addEventListener('click', () => {
            this.isCreatingTag = true;
            this.updateUI();
        });
        
        document.getElementById('confirm-create').addEventListener('click', () => this.confirmCreateTag());
        document.getElementById('cancel-create').addEventListener('click', () => this.cancelCreateTag());
        
        document.getElementById('add-nail-btn').addEventListener('click', () => this.handleNailAction('add_nail'));
        document.getElementById('remove-nail-btn').addEventListener('click', () => this.handleNailAction('remove_nail'));
        document.getElementById('close-popup').addEventListener('click', () => this.closePopup());
    }
    
    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight - 60;
    }
    
    handleMouseDown(e) {
        if (e.button === 0) { // 左键
            if (this.isCreatingTag) {
                const pos = this.getCanvasPosition(e);
                this.pendingTag = { x: pos.x, y: pos.y };
                this.showTagInput();
            } else {
                this.isDragging = true;
                this.lastMouseX = e.clientX;
                this.lastMouseY = e.clientY;
                this.canvas.style.cursor = 'grabbing';
            }
        }
    }
    
    handleMouseMove(e) {
        if (this.isDragging) {
            const deltaX = (e.clientX - this.lastMouseX) / this.scale;
            const deltaY = (e.clientY - this.lastMouseY) / this.scale;
            
            this.viewX = Math.max(0, Math.min(this.wallWidth - this.canvas.width / this.scale, this.viewX - deltaX));
            this.viewY = Math.max(0, Math.min(this.wallHeight - this.canvas.height / this.scale, this.viewY - deltaY));
            
            this.lastMouseX = e.clientX;
            this.lastMouseY = e.clientY;
            this.render();
        }
    }
    
    handleMouseUp(e) {
        this.isDragging = false;
        this.canvas.style.cursor = 'crosshair';
    }
    
    handleMouseWheel(e) {
        e.preventDefault();
        
        // 计算缩放因子
        const scaleFactor = e.deltaY > 0 ? 0.9 : 1.1;
        const newScale = Math.max(this.minScale, Math.min(this.maxScale, this.scale * scaleFactor));
        
        if (newScale !== this.scale) {
            // 获取鼠标在画布上的位置
            const rect = this.canvas.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;
            
            // 转换到墙面坐标
            const worldX = this.viewX + mouseX / this.scale;
            const worldY = this.viewY + mouseY / this.scale;
            
            // 应用缩放
            this.scale = newScale;
            
            // 调整视角，保持鼠标位置不变
            this.viewX = worldX - mouseX / this.scale;
            this.viewY = worldY - mouseY / this.scale;
            
            // 限制视角范围
            this.clampView();
            this.render();
        }
    }
    
    handleCanvasClick(e) {
        if (!this.isCreatingTag && !this.isDragging) {
            const pos = this.getCanvasPosition(e);
            const clickedTag = this.getTagAtPosition(pos.x, pos.y);
            if (clickedTag) {
                this.showTagPopup(clickedTag);
            }
        }
    }
    
    handleTouchStart(e) {
        e.preventDefault();
        
        if (e.touches.length === 1) {
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousedown', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            this.handleMouseDown(mouseEvent);
        } else if (e.touches.length === 2) {
            // 双指缩放
            this.isScaling = true;
            this.touchStartDistance = this.getTouchDistance(e.touches[0], e.touches[1]);
            this.scaleStart = this.scale;
            
            // 停止拖拽
            this.isDragging = false;
        }
    }
    
    handleTouchMove(e) {
        e.preventDefault();
        
        if (e.touches.length === 1 && !this.isScaling) {
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousemove', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            this.handleMouseMove(mouseEvent);
        } else if (e.touches.length === 2 && this.isScaling) {
            // 双指缩放
            const currentDistance = this.getTouchDistance(e.touches[0], e.touches[1]);
            
            if (this.touchStartDistance > 0) {
                const scaleFactor = currentDistance / this.touchStartDistance;
                const newScale = Math.max(this.minScale, Math.min(this.maxScale, this.scaleStart * scaleFactor));
                
                if (newScale !== this.scale) {
                    // 计算缩放中心（两指中心点）
                    const centerX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
                    const centerY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
                    
                    // 转换到墙面坐标
                    const rect = this.canvas.getBoundingClientRect();
                    const canvasX = centerX - rect.left;
                    const canvasY = centerY - rect.top;
                    const worldX = this.viewX + canvasX / this.scale;
                    const worldY = this.viewY + canvasY / this.scale;
                    
                    // 应用缩放
                    this.scale = newScale;
                    
                    // 调整视角，保持中心点不变
                    this.viewX = worldX - canvasX / this.scale;
                    this.viewY = worldY - canvasY / this.scale;
                    
                    // 限制视角范围
                    this.clampView();
                    this.render();
                }
            }
        }
    }
    
    handleTouchEnd(e) {
        e.preventDefault();
        
        if (e.touches.length === 0) {
            // 所有手指离开，结束缩放和拖拽
            this.isScaling = false;
            this.isDragging = false;
            
            const mouseEvent = new MouseEvent('mouseup', {});
            this.handleMouseUp(mouseEvent);
        } else if (e.touches.length === 1) {
            // 只有一个手指，结束缩放，开始拖拽
            this.isScaling = false;
            
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousedown', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            this.handleMouseDown(mouseEvent);
        }
    }
    
    getTouchDistance(touch1, touch2) {
        const dx = touch1.clientX - touch2.clientX;
        const dy = touch1.clientY - touch2.clientY;
        return Math.sqrt(dx * dx + dy * dy);
    }
    
    clampView() {
        // 计算缩放后可见的墙面区域
        const viewableWidth = this.canvas.width / this.scale;
        const viewableHeight = this.canvas.height / this.scale;
        
        // 限制视角范围在墙面范围内
        this.viewX = Math.max(0, Math.min(this.wallWidth - viewableWidth, this.viewX));
        this.viewY = Math.max(0, Math.min(this.wallHeight - viewableHeight, this.viewY));
    }
    
    getCanvasPosition(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) / this.scale + this.viewX;
        const y = (e.clientY - rect.top) / this.scale + this.viewY;
        return { x, y };
    }
    
    getTagAtPosition(x, y) {
        for (let tag of this.tags) {
            if (x >= tag.x - 60 && x <= tag.x + 60 && 
                y >= tag.y - 20 && y <= tag.y + 20) {
                return tag;
            }
        }
        return null;
    }
    
    showTagInput() {
        document.getElementById('tag-input').style.display = 'flex';
        document.getElementById('tag-text').focus();
    }
    
    hideTagInput() {
        document.getElementById('tag-input').style.display = 'none';
        document.getElementById('tag-text').value = '';
    }
    
    async confirmCreateTag() {
        const text = document.getElementById('tag-text').value.trim();
        if (!text) return;
        
        try {
            const response = await fetch('/api/tags', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    text: text,
                    color: this.selectedColor,
                    x: this.pendingTag.x,
                    y: this.pendingTag.y,
                    rotation: Math.random() * 30 - 15 // 随机倾斜角度
                })
            });
            
            if (response.ok) {
                const newTag = await response.json();
                this.tags.push(newTag);
                this.hideTagInput();
                this.isCreatingTag = false;
                this.updateUserSteps();
                this.render();
            } else {
                alert('创建标签失败，步数可能不足');
            }
        } catch (error) {
            console.error('创建标签失败:', error);
            alert('网络错误');
        }
    }
    
    cancelCreateTag() {
        this.hideTagInput();
        this.isCreatingTag = false;
        this.pendingTag = null;
        this.updateUI();
    }
    
    showTagPopup(tag) {
        const popup = document.getElementById('tag-popup');
        const info = document.getElementById('tag-info');
        
        info.textContent = `"${tag.text}" - 钉子数: ${tag.nails}`;
        
        const isOwner = tag.creator === this.userId;
        document.getElementById('add-nail-btn').style.display = isOwner ? 'inline-block' : 'none';
        document.getElementById('remove-nail-btn').style.display = isOwner ? 'inline-block' : 'none';
        
        popup.dataset.tagId = tag.id;
        popup.style.display = 'flex';
    }
    
    closePopup() {
        document.getElementById('tag-popup').style.display = 'none';
    }
    
    async handleNailAction(action) {
        const tagId = document.getElementById('tag-popup').dataset.tagId;
        
        try {
            const response = await fetch(`/api/tags/${tagId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ action })
            });
            
            if (response.ok) {
                const result = await response.json();
                
                if (result.deleted) {
                    // 标签被删除
                    this.tags = this.tags.filter(tag => tag.id !== tagId);
                } else {
                    // 更新标签信息
                    const index = this.tags.findIndex(tag => tag.id === tagId);
                    if (index !== -1) {
                        this.tags[index] = result;
                    }
                }
                
                this.updateUserSteps();
                this.closePopup();
                this.render();
            } else {
                alert('操作失败');
            }
        } catch (error) {
            console.error('操作失败:', error);
            alert('网络错误');
        }
    }
    
    updateUserSteps() {
        const stepsCookie = document.cookie.split('; ').find(row => row.startsWith('steps='));
        if (stepsCookie) {
            this.userSteps = parseInt(stepsCookie.split('=')[1]);
        }
        this.updateUI();
    }
    
    updateUI() {
        document.getElementById('steps-display').textContent = `步数: ${this.userSteps} | 缩放: ${Math.round(this.scale * 100)}%`;
        document.getElementById('create-tag-btn').disabled = this.userSteps <= 0;
        document.getElementById('create-tag-btn').textContent = 
            this.isCreatingTag ? '点击墙上放置标签' : 
            (this.userSteps > 0 ? '创建标签' : '步数不足');
    }
    
    render() {
        // 清空画布
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // 应用缩放变换
        this.ctx.save();
        this.ctx.scale(this.scale, this.scale);
        this.ctx.translate(-this.viewX, -this.viewY);
        
        // 绘制墙面背景
        this.ctx.fillStyle = '#e8e8e8';
        this.ctx.fillRect(0, 0, this.wallWidth, this.wallHeight);
        
        // 绘制墙面纹理
        this.drawWallTexture();
        
        // 绘制标签
        this.tags.forEach(tag => this.drawTag(tag));
        
        // 绘制创建中的标签预览
        if (this.isCreatingTag && this.pendingTag) {
            this.drawTagPreview();
        }
        
        // 恢复变换
        this.ctx.restore();
        
        // 绘制界面元素（不受缩放影响）
        this.drawUI();
    }
    
    drawWallTexture() {
        const gridSize = 50;
        this.ctx.strokeStyle = '#d0d0d0';
        this.ctx.lineWidth = 1 / this.scale; // 根据缩放调整线宽
        
        // 计算可见区域
        const viewLeft = this.viewX;
        const viewTop = this.viewY;
        const viewRight = this.viewX + this.canvas.width / this.scale;
        const viewBottom = this.viewY + this.canvas.height / this.scale;
        
        // 绘制垂直网格线
        const startX = Math.floor(viewLeft / gridSize) * gridSize;
        for (let x = startX; x <= viewRight; x += gridSize) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, viewTop);
            this.ctx.lineTo(x, viewBottom);
            this.ctx.stroke();
        }
        
        // 绘制水平网格线
        const startY = Math.floor(viewTop / gridSize) * gridSize;
        for (let y = startY; y <= viewBottom; y += gridSize) {
            this.ctx.beginPath();
            this.ctx.moveTo(viewLeft, y);
            this.ctx.lineTo(viewRight, y);
            this.ctx.stroke();
        }
    }
    
    drawTag(tag) {
        // 检查是否在可视区域内
        const viewLeft = this.viewX - 120 / this.scale;
        const viewRight = this.viewX + this.canvas.width / this.scale + 120 / this.scale;
        const viewTop = this.viewY - 60 / this.scale;
        const viewBottom = this.viewY + this.canvas.height / this.scale + 60 / this.scale;
        
        if (tag.x < viewLeft || tag.x > viewRight || 
            tag.y < viewTop || tag.y > viewBottom) {
            return;
        }
        
        this.ctx.save();
        this.ctx.translate(tag.x, tag.y);
        this.ctx.rotate((tag.rotation * Math.PI) / 180);
        
        // 绘制标签背景
        this.ctx.fillStyle = tag.color;
        this.ctx.fillRect(-60, -20, 120, 40);
        
        // 绘制标签边框
        this.ctx.strokeStyle = '#333';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(-60, -20, 120, 40);
        
        // 绘制文字
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(tag.text, 0, 0);
        
        // 绘制钉子数量
        this.ctx.fillStyle = '#333';
        this.ctx.beginPath();
        this.ctx.arc(50, -15, 10, 0, 2 * Math.PI);
        this.ctx.fill();
        
        this.ctx.fillStyle = 'white';
        this.ctx.font = 'bold 10px Arial';
        this.ctx.fillText(tag.nails.toString(), 50, -15);
        
        this.ctx.restore();
    }
    
    drawTagPreview() {
        this.ctx.save();
        this.ctx.globalAlpha = 0.5;
        this.ctx.translate(this.pendingTag.x, this.pendingTag.y);
        
        // 绘制预览标签
        this.ctx.fillStyle = this.selectedColor;
        this.ctx.fillRect(-60, -20, 120, 40);
        
        this.ctx.strokeStyle = '#333';
        this.ctx.lineWidth = 2;
        this.ctx.setLineDash([5, 5]);
        this.ctx.strokeRect(-60, -20, 120, 40);
        
        this.ctx.restore();
    }
    
    drawUI() {
        // 绘制坐标和缩放指示器
        this.ctx.fillStyle = '#666';
        this.ctx.font = '12px Arial';
        const info = `坐标: (${Math.round(this.viewX)}, ${Math.round(this.viewY)}) 缩放: ${Math.round(this.scale * 100)}%`;
        this.ctx.fillText(info, 10, this.canvas.height - 10);
    }
}

// 初始化应用
document.addEventListener('DOMContentLoaded', () => {
    new WallSystem();
});