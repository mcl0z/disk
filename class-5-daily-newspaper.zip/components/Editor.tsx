import React, { useState } from 'react';
import { Report, ContentBlock } from '../types';
import { compressImage, uploadFile } from '../services/api';

interface EditorProps {
  initialData?: Report;
  onSave: (report: Partial<Report>) => Promise<void>;
  onCancel: () => void;
  onDelete?: (id: string) => Promise<void>;
}

export const Editor: React.FC<EditorProps> = ({ initialData, onSave, onCancel, onDelete }) => {
  const [title, setTitle] = useState(initialData?.title || '');
  const [author, setAuthor] = useState(initialData?.author || '');
  const [published, setPublished] = useState(initialData?.published ?? true);
  const [blocks, setBlocks] = useState<ContentBlock[]>(initialData?.blocks || [{ id: Date.now().toString(), type: 'text', content: '' }]);
  const [isSaving, setIsSaving] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});

  const addBlock = (type: 'text' | 'image' | 'file') => {
    setBlocks([...blocks, { id: Date.now().toString(), type, content: '' }]);
  };

  const removeBlock = (id: string) => {
    setBlocks(blocks.filter(b => b.id !== id));
  };

  const updateBlock = (id: string, field: keyof ContentBlock, value: string) => {
    setBlocks(blocks.map(b => b.id === id ? { ...b, [field]: value } : b));
  };

  const handleFileUpload = async (id: string, file: File, type: 'image' | 'file') => {
    try {
      setUploadProgress(prev => ({ ...prev, [id]: 10 })); // Start progress
      
      let fileToUpload = file;
      if (type === 'image') {
        // Mock progress for compression
        setUploadProgress(prev => ({ ...prev, [id]: 30 }));
        fileToUpload = await compressImage(file);
        setUploadProgress(prev => ({ ...prev, [id]: 50 }));
      }

      // Upload
      const { url } = await uploadFile(fileToUpload);
      setUploadProgress(prev => ({ ...prev, [id]: 100 }));
      
      updateBlock(id, 'content', url);
      
      // Clear progress after delay
      setTimeout(() => {
        setUploadProgress(prev => {
          const next = { ...prev };
          delete next[id];
          return next;
        });
      }, 1000);

    } catch (err) {
      console.error(err);
      alert('Upload failed');
      setUploadProgress(prev => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !author.trim()) return alert('请填写标题和作者');
    
    setIsSaving(true);
    try {
      await onSave({
        id: initialData?.id,
        title,
        author,
        published,
        blocks,
        date: initialData?.date || new Date().toISOString(),
      });
    } catch (error) {
      alert('保存失败');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-white p-8 border border-ink shadow-lg max-w-4xl mx-auto font-serif">
      <div className="border-b-2 border-ink pb-4 mb-6 flex justify-between items-center">
        <h2 className="text-3xl font-bold text-ink">
            <i className="fas fa-edit mr-2"></i> 
            {initialData ? '编辑稿件' : '撰写新稿'}
        </h2>
        <button onClick={onCancel} className="text-ink-light hover:text-ink">
            &times; 关闭
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-bold uppercase tracking-wider text-ink-light mb-1">标题 Headline</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full border-b-2 border-ink bg-stone-50 p-2 text-xl font-bold focus:outline-none focus:bg-stone-100 transition-colors placeholder-gray-400"
              placeholder="输入大标题..."
              required
            />
          </div>
          <div>
            <label className="block text-sm font-bold uppercase tracking-wider text-ink-light mb-1">作者 Author</label>
            <input
              type="text"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              className="w-full border-b-2 border-ink bg-stone-50 p-2 text-lg focus:outline-none focus:bg-stone-100 transition-colors placeholder-gray-400"
              placeholder="记者姓名..."
              required
            />
          </div>
        </div>

        <div className="space-y-4">
          <label className="block text-sm font-bold uppercase tracking-wider text-ink-light border-b border-gray-200 pb-2">
            正文内容 Blocks
          </label>
          
          {blocks.map((block, index) => (
            <div key={block.id} className="relative group border border-dashed border-gray-300 p-4 rounded bg-stone-50 hover:border-ink transition-colors">
              <div className="absolute top-2 right-2 flex space-x-2 opacity-50 group-hover:opacity-100 transition-opacity">
                <button type="button" onClick={() => removeBlock(block.id)} className="text-red-600 hover:text-red-800 p-1">
                  <span className="sr-only">Delete</span> 🗑️
                </button>
              </div>
              
              <span className="text-xs font-bold text-gray-400 uppercase mb-2 block">{index + 1}. {block.type}</span>

              {block.type === 'text' && (
                <textarea
                  value={block.content}
                  onChange={(e) => updateBlock(block.id, 'content', e.target.value)}
                  className="w-full min-h-[120px] p-2 bg-white border border-gray-200 focus:border-ink focus:outline-none font-serif text-lg leading-relaxed resize-y"
                  placeholder="在此输入正文..."
                />
              )}

              {(block.type === 'image' || block.type === 'file') && (
                <div className="space-y-3">
                  <div className="flex items-center space-x-4">
                    <label className="cursor-pointer bg-white border border-gray-300 px-4 py-2 hover:bg-gray-50 transition-colors shadow-sm text-sm font-bold flex items-center">
                       <span>📁 选择{block.type === 'image' ? '图片' : '文件'}</span>
                       <input 
                         type="file" 
                         className="hidden" 
                         accept={block.type === 'image' ? "image/*" : "*"}
                         onChange={(e) => e.target.files?.[0] && handleFileUpload(block.id, e.target.files[0], block.type)}
                       />
                    </label>
                    <input
                      type="text"
                      value={block.content}
                      onChange={(e) => updateBlock(block.id, 'content', e.target.value)}
                      className="flex-1 p-2 border border-gray-200 text-sm font-mono bg-white"
                      placeholder={block.type === 'image' ? "或输入图片 URL..." : "文件 URL..."}
                    />
                  </div>

                  {uploadProgress[block.id] !== undefined && (
                    <div className="w-full bg-gray-200 h-2 mt-2">
                      <div className="bg-green-600 h-2 transition-all duration-300" style={{ width: `${uploadProgress[block.id]}%` }}></div>
                    </div>
                  )}

                  {block.type === 'image' && block.content && (
                    <div className="flex gap-4 items-start">
                        <img src={block.content} alt="Preview" className="h-32 object-contain border border-gray-200 bg-white p-1" />
                        <input
                            type="text"
                            value={block.meta || ''}
                            onChange={(e) => updateBlock(block.id, 'meta', e.target.value)}
                            className="flex-1 p-2 border border-gray-200 text-sm"
                            placeholder="图片说明/图注 (caption)..."
                        />
                    </div>
                  )}
                  {block.type === 'file' && block.content && (
                       <input
                       type="text"
                       value={block.meta || ''}
                       onChange={(e) => updateBlock(block.id, 'meta', e.target.value)}
                       className="w-full p-2 border border-gray-200 text-sm"
                       placeholder="下载链接显示的文字..."
                   />
                  )}
                </div>
              )}
            </div>
          ))}

          <div className="flex justify-center space-x-4 py-4 border-t border-dashed border-gray-300">
             <button type="button" onClick={() => addBlock('text')} className="px-4 py-2 bg-stone-100 hover:bg-stone-200 border border-stone-300 text-ink text-sm font-bold transition-colors">
               + 添加文本 Text
             </button>
             <button type="button" onClick={() => addBlock('image')} className="px-4 py-2 bg-stone-100 hover:bg-stone-200 border border-stone-300 text-ink text-sm font-bold transition-colors">
               + 添加图片 Image
             </button>
             <button type="button" onClick={() => addBlock('file')} className="px-4 py-2 bg-stone-100 hover:bg-stone-200 border border-stone-300 text-ink text-sm font-bold transition-colors">
               + 添加文件 File
             </button>
          </div>
        </div>

        <div className="flex items-center space-x-2 pt-4 border-t border-ink">
          <input
            type="checkbox"
            id="published"
            checked={published}
            onChange={(e) => setPublished(e.target.checked)}
            className="w-5 h-5 accent-ink"
          />
          <label htmlFor="published" className="font-bold cursor-pointer select-none">立即发布 (Publish Immediately)</label>
        </div>

        <div className="flex justify-between items-center pt-4">
          {onDelete && initialData?.id && (
            <button
              type="button"
              onClick={() => onDelete(initialData.id)}
              className="px-6 py-3 bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 font-bold transition-colors"
            >
              删除 Delete
            </button>
          )}
          <div className="flex space-x-4 ml-auto">
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-3 border border-ink text-ink hover:bg-stone-100 font-bold transition-colors"
            >
              取消 Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-8 py-3 bg-ink text-paper hover:bg-ink-light font-bold shadow-md transition-all transform active:scale-95 disabled:opacity-50"
            >
              {isSaving ? '保存中...' : '提交 Save Report'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
