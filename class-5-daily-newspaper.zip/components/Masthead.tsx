import React from 'react';

export const Masthead: React.FC = () => {
  const today = new Date();
  const dateStr = today.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    weekday: 'long'
  });

  return (
    <header className="border-b-4 border-double border-ink mb-8 select-none">
      {/* Top utility bar */}
      <div className="flex justify-between text-xs font-serif border-b border-ink/20 py-1 mb-4 text-ink-light">
        <span>国内统一刊号: CLASS-5-001</span>
        <span>今日天气: 晴转多云 24°C</span>
      </div>

      {/* Main Title */}
      <div className="text-center relative py-4">
        <h1 className="text-6xl md:text-8xl font-black font-serif tracking-widest text-ink uppercase" style={{ textShadow: '2px 2px 0px rgba(0,0,0,0.1)' }}>
          五班日报
        </h1>
        <div className="absolute top-0 right-0 hidden md:block w-32 text-right">
             <div className="bg-ink text-paper text-xs inline-block px-2 py-1 mb-1 font-bold">每日必读</div>
             <p className="text-xs text-ink-light italic">记录班级每一刻</p>
        </div>
      </div>

      {/* Sub-header info bar */}
      <div className="flex flex-col md:flex-row justify-between items-center border-t-2 border-b-2 border-ink py-2 mt-4 font-serif">
        <div className="text-sm font-bold">{dateStr}</div>
        <div className="italic text-ink-light">战地记者这一块</div>
        <div className="text-sm font-bold">第 1928 期</div>
      </div>
    </header>
  );
};
