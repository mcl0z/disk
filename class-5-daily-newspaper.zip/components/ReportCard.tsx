import React from 'react';
import { Report, ContentBlock } from '../types';

interface ReportCardProps {
  report: Report;
  onClick: (report: Report) => void;
  featured?: boolean; // If true, renders as a headline story
}

export const ReportCard: React.FC<ReportCardProps> = ({ report, onClick, featured = false }) => {
  // Helper to render preview content safely
  const renderPreview = (blocks: ContentBlock[]) => {
    // Find first image for thumbnail if not featured
    const imageBlock = blocks.find(b => b.type === 'image');
    
    // Get text content
    const textBlocks = blocks.filter(b => b.type === 'text');
    const fullText = textBlocks.map(b => b.content).join(' ');
    const previewText = fullText.slice(0, featured ? 300 : 150) + (fullText.length > 150 ? '...' : '');

    return (
      <div className="space-y-3">
        {imageBlock && (
          <div className={`overflow-hidden border border-ink/20 ${featured ? 'mb-4' : 'float-left mr-3 mb-1 w-1/3'}`}>
            <img 
              src={imageBlock.content} 
              alt={imageBlock.meta || 'News image'} 
              className={`w-full h-auto object-cover filter grayscale hover:grayscale-0 transition-all duration-500 ${featured ? 'max-h-[400px]' : 'aspect-square'}`}
            />
            {imageBlock.meta && featured && (
              <p className="text-xs text-center italic text-ink-light mt-1 border-b border-ink/10 pb-1">{imageBlock.meta}</p>
            )}
          </div>
        )}
        <p className={`font-serif text-ink-light text-justify leading-relaxed ${featured ? 'text-lg drop-cap' : 'text-sm'}`}>
          {previewText}
        </p>
      </div>
    );
  };

  return (
    <article 
      onClick={() => onClick(report)}
      className={`
        break-inside-avoid mb-8 cursor-pointer group
        ${featured ? 'col-span-full border-b-4 border-ink pb-6 mb-8' : 'border-b border-ink/20 pb-4'}
      `}
    >
      <div className="mb-2">
        {featured && <span className="inline-block bg-accent text-white text-xs px-2 py-0.5 mb-2 font-bold uppercase tracking-wider">头条 HeadLine</span>}
        <h3 className={`font-serif font-bold text-ink group-hover:text-accent transition-colors leading-tight ${featured ? 'text-4xl mb-4 text-center' : 'text-xl mb-2'}`}>
          {report.title}
        </h3>
        <div className={`flex items-center text-xs text-ink-light mb-3 font-sans ${featured ? 'justify-center' : ''}`}>
           <span className="font-bold mr-2 uppercase">{report.author}</span>
           <span className="w-1 h-1 bg-ink/40 rounded-full mx-2"></span>
           <span>{new Date(report.date).toLocaleDateString()}</span>
        </div>
      </div>

      {renderPreview(report.blocks)}
      
      <div className="clear-both mt-2 pt-2">
         <span className="text-accent text-xs font-bold font-sans group-hover:underline">阅读全文 &rarr;</span>
      </div>
    </article>
  );
};
