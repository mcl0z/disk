import { Report, Comment } from '../types';

const API_BASE_URL = '/api'; // In a real app, this would be process.env.REACT_APP_API_URL

// Helper for headers
const getHeaders = (token?: string) => {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Basic ${token}`;
  }
  return headers;
};

// Image Compression Service
export const compressImage = async (file: File, maxSizeKB = 300): Promise<File> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) return reject(new Error('Canvas context not available'));

        let width = img.width;
        let height = img.height;
        const maxWidth = 1200;
        const maxHeight = 1200;

        if (width > maxWidth || height > maxHeight) {
          const ratio = Math.min(maxWidth / width, maxHeight / height);
          width *= ratio;
          height *= ratio;
        }

        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(img, 0, 0, width, height);

        let quality = 0.9;
        const compress = () => {
          canvas.toBlob(
            (blob) => {
              if (!blob) return reject(new Error('Compression failed'));
              if (blob.size / 1024 > maxSizeKB && quality > 0.1) {
                quality -= 0.1;
                compress();
              } else {
                const compressedFile = new File([blob], file.name, {
                  type: 'image/jpeg',
                  lastModified: Date.now(),
                });
                resolve(compressedFile);
              }
            },
            'image/jpeg',
            quality
          );
        };
        compress();
      };
      img.onerror = (err) => reject(err);
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
};

// API Calls (Mocking the fetch structure from original code)

export const fetchPublishedReports = async (): Promise<Report[]> => {
  try {
    const res = await fetch(`${API_BASE_URL}/reports/published`);
    if (!res.ok) throw new Error('Failed to fetch');
    return await res.json();
  } catch (e) {
    console.warn("API fail, returning mock data for demo", e);
    return MOCK_REPORTS;
  }
};

export const fetchHistoryReports = async (): Promise<Report[]> => {
  try {
    const res = await fetch(`${API_BASE_URL}/reports/history`);
    if (!res.ok) throw new Error('Failed to fetch');
    return await res.json();
  } catch (e) {
    return MOCK_REPORTS;
  }
};

export const fetchReportById = async (id: string): Promise<Report | null> => {
  try {
    const res = await fetch(`${API_BASE_URL}/reports/${id}`);
    if (!res.ok) throw new Error('Failed to fetch');
    return await res.json();
  } catch (e) {
    return MOCK_REPORTS.find(r => r.id === id) || null;
  }
};

export const saveReport = async (report: Partial<Report>, token?: string): Promise<Report> => {
  // Simulate API call
  const isEdit = !!report.id;
  const url = isEdit ? `${API_BASE_URL}/reports/${report.id}` : `${API_BASE_URL}/reports`;
  const method = isEdit ? 'PUT' : 'POST';

  // In a real scenario:
  /*
  const res = await fetch(url, {
    method,
    headers: getHeaders(token),
    body: JSON.stringify(report),
  });
  if (!res.ok) throw new Error('Save failed');
  return await res.json();
  */
 
  // For Demo:
  return { ...report, id: report.id || Date.now().toString() } as Report;
};

export const deleteReport = async (id: string, token: string): Promise<void> => {
  /*
  await fetch(`${API_BASE_URL}/reports/${id}`, {
    method: 'DELETE',
    headers: getHeaders(token),
  });
  */
};

export const uploadFile = async (file: File): Promise<{ url: string }> => {
  // In real app, upload to server. Here we pretend.
  // const formData = new FormData();
  // formData.append('file', file);
  // const res = await fetch(`${API_BASE_URL}/upload`, { method: 'POST', body: formData });
  // return await res.json();
  
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ url: URL.createObjectURL(file) });
    }, 1000);
  });
};

// Mock Data for Visualization
const MOCK_REPORTS: Report[] = [
  {
    id: '1',
    title: '五班赢得篮球比赛冠军',
    author: '体育委员',
    date: new Date().toISOString(),
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    blocks: [
      {
        id: 'b1',
        type: 'text',
        content: '在昨天下午举行的年级篮球决赛中，五班代表队以58:56险胜三班，夺得本学期首个冠军奖杯。比赛过程异常激烈，最后一分钟的比分一度胶着。'
      },
      {
        id: 'b2',
        type: 'image',
        content: 'https://picsum.photos/800/400',
        meta: '五班队员庆祝胜利时刻'
      },
      {
        id: 'b3',
        type: 'text',
        content: '队长李明在赛后采访中表示：“这是大家共同努力的结果，特别是张伟在最后时刻的三分球，简直是神来之笔。” 班主任王老师也到场为同学们加油助威，并承诺免除今天的数学作业以示庆祝（假的）。'
      }
    ]
  },
  {
    id: '2',
    title: '期中考试安排公布',
    author: '学习委员',
    date: new Date().toISOString(),
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    blocks: [
      {
        id: 'b4',
        type: 'text',
        content: '下周三至周五将进行为期三天的期中考试。请各位同学做好复习准备，带好文具。具体考场安排已张贴在教室后黑板。'
      }
    ]
  },
  {
    id: '3',
    title: '关于春游的建议征集',
    author: '班长',
    date: new Date().toISOString(),
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    blocks: [
      {
        id: 'b5',
        type: 'text',
        content: '本学期的春游计划正在筹备中。目前备选地点有：植物园、科技馆和森林公园。请大家在周五前将意向告诉各组组长。'
      },
      {
         id: 'b6',
         type: 'image',
         content: 'https://picsum.photos/400/300',
         meta: '去年的植物园合影'
      }
    ]
  }
];
