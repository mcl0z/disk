import React, { useState, useEffect } from 'react';
import { Masthead } from './components/Masthead';
import { ReportCard } from './components/ReportCard';
import { Editor } from './components/Editor';
import { Report, PageView, User } from './types';
import { fetchPublishedReports, fetchHistoryReports, saveReport, deleteReport, fetchReportById } from './services/api';

const App: React.FC = () => {
  const [view, setView] = useState<PageView>('home');
  const [reports, setReports] = useState<Report[]>([]);
  const [currentReport, setCurrentReport] = useState<Report | null>(null);
  const [user, setUser] = useState<User>({ username: 'Guest', isAdmin: false });
  const [loading, setLoading] = useState(false);

  // Admin Auth Logic (Mock)
  const handleLogin = () => {
    const password = prompt("Admin Password (try 'admin'):");
    if (password === 'admin') {
      const mockUser = { username: 'Admin', isAdmin: true, token: 'mock-token' };
      setUser(mockUser);
      localStorage.setItem('adminToken', 'mock-token');
    } else if (password) {
      alert("Access Denied");
    }
  };
  
  const handleLogout = () => {
    setUser({ username: 'Guest', isAdmin: false });
    localStorage.removeItem('adminToken');
    setView('home');
  };

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    if (token) {
        setUser({ username: 'Admin', isAdmin: true, token });
    }
    loadData('home');
  }, []);

  const loadData = async (targetView: PageView) => {
    setLoading(true);
    try {
        if (targetView === 'home' || targetView === 'published') {
            const data = await fetchPublishedReports();
            setReports(data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        } else if (targetView === 'history') {
            const data = await fetchHistoryReports();
            setReports(data);
        }
    } finally {
        setLoading(false);
    }
  };

  const handleNav = (target: PageView) => {
    setView(target);
    setCurrentReport(null);
    loadData(target);
  };

  const handleEditClick = (report?: Report) => {
    if (!user.isAdmin) {
        alert("Only Admins can edit.");
        return;
    }
    setCurrentReport(report || null);
    setView('edit');
  };

  const handleSaveReport = async (data: Partial<Report>) => {
    await saveReport(data, user.token);
    handleNav('home');
  };

  const handleDeleteReport = async (id: string) => {
     if(confirm("Are you sure? This cannot be undone.")) {
         await deleteReport(id, user.token || '');
         handleNav('home');
     }
  };

  const handleReportClick = (report: Report) => {
      setCurrentReport(report);
      setView('detail');
  };

  // --- RENDER HELPERS ---

  const renderHome = () => {
    if (loading) return <div className="text-center p-10 font-serif italic text-xl">Loading the press...</div>;
    
    // Logic: First item is headline (featured), rest are columns
    const featured = reports[0];
    const rest = reports.slice(1);

    return (
      <div className="animate-fade-in">
        {featured ? (
             <ReportCard report={featured} onClick={handleReportClick} featured />
        ) : (
            <div className="text-center py-20 border-b border-ink">No headlines today.</div>
        )}
        
        {/* Masonry-like newspaper columns */}
        <div className="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8">
          {rest.map(report => (
            <div key={report.id} className="break-inside-avoid">
               <ReportCard report={report} onClick={handleReportClick} />
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderDetail = () => {
      if (!currentReport) return null;
      return (
          <div className="max-w-3xl mx-auto bg-white p-8 md:p-12 shadow-paper border border-ink/10 relative">
             <button onClick={() => setView('home')} className="absolute -left-4 top-0 md:-left-16 md:top-4 bg-ink text-paper w-10 h-10 flex items-center justify-center rounded-full shadow-lg hover:scale-110 transition-transform">
                 &larr;
             </button>
             
             {user.isAdmin && (
                 <div className="mb-6 flex gap-2 justify-end">
                     <button onClick={() => handleEditClick(currentReport)} className="text-xs bg-ink/10 px-2 py-1 hover:bg-ink/20 rounded">Edit</button>
                 </div>
             )}

             <div className="text-center mb-8 border-b-2 border-ink pb-6">
                 <h1 className="text-4xl md:text-5xl font-serif font-black mb-4 leading-tight">{currentReport.title}</h1>
                 <div className="flex justify-center items-center text-sm font-sans text-gray-500 space-x-4">
                     <span className="font-bold text-ink uppercase tracking-widest">{currentReport.author}</span>
                     <span>&bull;</span>
                     <span>{new Date(currentReport.date).toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                 </div>
             </div>

             <div className="prose prose-lg prose-stone mx-auto font-serif text-justify">
                 {currentReport.blocks.map(block => {
                     if (block.type === 'text') {
                         return <p key={block.id} className="whitespace-pre-wrap mb-4 indent-8">{block.content}</p>;
                     }
                     if (block.type === 'image') {
                         return (
                             <figure key={block.id} className="my-8">
                                 <img src={block.content} alt={block.meta} className="w-full h-auto border border-gray-200 p-1 bg-white shadow-sm" />
                                 {block.meta && <figcaption className="text-center text-sm italic text-gray-500 mt-2 font-sans">{block.meta}</figcaption>}
                             </figure>
                         );
                     }
                     if (block.type === 'file') {
                         return (
                             <div key={block.id} className="my-6 p-4 border border-dashed border-gray-400 bg-gray-50 flex items-center justify-between">
                                 <span className="font-bold text-sm">📎 附件 Attachment</span>
                                 <a href={block.content} target="_blank" rel="noreferrer" className="text-blue-700 hover:underline text-sm font-bold">
                                     {block.meta || 'Download File'}
                                 </a>
                             </div>
                         );
                     }
                     return null;
                 })}
             </div>
          </div>
      );
  };

  return (
    <div className="min-h-screen bg-newspaper-texture text-ink pb-20 overflow-x-hidden">
      <div className="container mx-auto px-4 max-w-6xl pt-6">
        
        {/* Toolbar */}
        <div className="flex justify-end gap-3 mb-4 text-xs font-bold font-sans uppercase tracking-widest">
            {user.isAdmin ? (
                 <>
                   <span className="text-green-700 self-center">Welcome, Admin</span>
                   <button onClick={handleLogout} className="hover:text-red-600 underline">Logout</button>
                 </>
            ) : (
                <button onClick={handleLogin} className="hover:text-ink-light underline">Admin Login</button>
            )}
        </div>

        <Masthead />

        {/* Navigation Bar */}
        <nav className="flex justify-center flex-wrap gap-4 md:gap-8 border-t border-b border-ink py-3 mb-10 sticky top-0 bg-[#fdfbf7] z-10 shadow-sm">
            {[
                { id: 'home', label: '首页 Front Page' },
                { id: 'history', label: '历史 Archives' },
                { id: 'published', label: '已发布 Published' },
            ].map(item => (
                <button
                    key={item.id}
                    onClick={() => handleNav(item.id as PageView)}
                    className={`font-serif font-bold text-sm md:text-base uppercase tracking-wider px-2 py-1 transition-colors
                        ${view === item.id ? 'bg-ink text-paper' : 'text-ink hover:text-accent'}
                    `}
                >
                    {item.label}
                </button>
            ))}
            {user.isAdmin && (
                <button 
                    onClick={() => handleEditClick()} 
                    className={`font-serif font-bold text-sm md:text-base uppercase tracking-wider px-2 py-1 text-red-700 hover:bg-red-50 border border-transparent hover:border-red-200 ${view === 'edit' ? 'bg-red-100' : ''}`}
                >
                    + 撰写 Write
                </button>
            )}
        </nav>

        {/* Content Area */}
        <main>
          {view === 'edit' && (
            <Editor 
                initialData={currentReport || undefined} 
                onSave={handleSaveReport} 
                onCancel={() => setView('home')}
                onDelete={handleDeleteReport}
            />
          )}

          {view === 'detail' && renderDetail()}
          
          {(view === 'home' || view === 'history' || view === 'published') && renderHome()}
        </main>

        {/* Footer */}
        <footer className="mt-20 border-t-4 border-double border-ink pt-8 text-center text-sm font-serif text-ink-light">
             <p>&copy; {new Date().getFullYear()} Class 5 Daily. All rights reserved.</p>
             <p className="mt-2 text-xs">Printed on virtual paper.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
