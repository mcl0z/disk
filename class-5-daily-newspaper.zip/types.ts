export interface ContentBlock {
  id: string;
  type: 'text' | 'image' | 'file';
  content: string;
  meta?: string; // Captions for images, filenames for files
}

export interface Report {
  id: string;
  title: string;
  author: string;
  date: string;
  published: boolean;
  blocks: ContentBlock[];
  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  id: string;
  reportId: string;
  author: string;
  content: string;
  date: string;
}

export interface User {
  username: string;
  isAdmin: boolean;
  token?: string;
}

// Navigation types
export type PageView = 'home' | 'edit' | 'history' | 'published' | 'detail';
