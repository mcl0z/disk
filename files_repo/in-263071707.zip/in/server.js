const express = require('express');
const axios = require('axios');
const app = express();

// 解析 JSON 请求体
app.use(express.json());

// 静态文件服务（前端页面）
app.use(express.static('public'));

// 配置目标 API 基础地址
const API_BASE_URL = 'http://60.205.94.101:8080/v1';

// ---------- 登录代理 ----------
app.post('/api/login', async (req, res) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/auth/login`, req.body, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 10000
    });
    // 原样返回 API 的响应数据
    res.status(response.status).json(response.data);
  } catch (error) {
    if (error.response) {
      // API 返回了错误状态码（如 401）
      res.status(error.response.status).json(error.response.data);
    } else {
      // 网络错误或超时
      res.status(500).json({ error: '代理请求失败', details: error.message });
    }
  }
});

// ---------- 获取当前用户信息 (需要 token) ----------
app.get('/api/me', async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: '缺少 Authorization 头' });
  }

  try {
    const response = await axios.get(`${API_BASE_URL}/me`, {
      headers: { Authorization: authHeader },
      timeout: 10000
    });
    res.status(response.status).json(response.data);
  } catch (error) {
    if (error.response) {
      res.status(error.response.status).json(error.response.data);
    } else {
      res.status(500).json({ error: '代理请求失败', details: error.message });
    }
  }
});

// ---------- 刷新 token ----------
app.post('/api/refresh', async (req, res) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/auth/refresh`, req.body, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 10000
    });
    res.status(response.status).json(response.data);
  } catch (error) {
    if (error.response) {
      res.status(error.response.status).json(error.response.data);
    } else {
      res.status(500).json({ error: '代理请求失败', details: error.message });
    }
  }
});

// 启动服务
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`代理服务运行在 http://localhost:${PORT}`);
  console.log(`前端页面访问地址：http://localhost:${PORT}`);
});