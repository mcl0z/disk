# 🔧 故障排查指南

## 常见问题和解决方案

### 1. ❌ Minecraft 连接中断或重置

#### 症状
- Minecraft 客户端显示"连接中断"
- 日志显示 `Connection reset` 或 `Connection lost`
- 无法加入服务器

#### 可能原因
1. **缓冲区太小**：Minecraft 数据包可能很大（特别是区块数据）
2. **网络不稳定**：丢包或延迟过高
3. **本地 MC 服务器未启动**：房主端 MC 服务器没有运行
4. **端口配置错误**：端口号不匹配

#### 解决方案

✅ **已优化的部分：**
- 缓冲区大小已增加到 64KB
- 添加了更好的错误处理和日志
- 改进了连接保持逻辑

✅ **检查清单：**

**房主端：**
```bash
# 1. 确认 Minecraft 服务器正在运行
netstat -an | grep 25565
# 应该看到: tcp4  0  0  *.25565  *.*  LISTEN

# 2. 测试本地连接
telnet 127.0.0.1 25565
# 应该能连接成功

# 3. 检查防火墙
# macOS
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate

# Linux
sudo ufw status
```

**玩家端：**
```bash
# 1. 测试到中继服务器的连接
telnet 185.239.87.249 25600
# 应该能连接成功

# 2. 检查本地端口是否被占用
netstat -an | grep 25565
# 不应该有其他程序占用
```

---

### 2. ❌ 房主连接后立即断开

#### 症状
```
[INFO] 房主已连接到中继服务器
[INFO] 等待客户端连接...
[INFO] 房主断开连接
```

#### 原因
- 本地 Minecraft 服务器未启动
- 端口配置错误

#### 解决方案
```bash
# 启动 Minecraft 服务器
cd /path/to/minecraft/server
java -Xmx1024M -Xms1024M -jar server.jar nogui

# 等待服务器完全启动（看到 "Done!"）
# 然后再启动客户端
```

---

### 3. ❌ 客户端无法获取中继服务器列表

#### 症状
```
[ERROR] 获取中继服务器列表失败
```

#### 解决方案
```bash
# 1. 检查 Tracker 服务器是否运行
curl http://124.71.76.131:9000/health

# 2. 检查网络连接
ping 124.71.76.131

# 3. 检查 Tracker 配置
# 在客户端设置中确认 Tracker 地址正确
```

---

### 4. ❌ 中继服务器无法注册到 Tracker

#### 症状
```
[ERROR] 注册到 Tracker 失败
```

#### 解决方案
```bash
# 1. 检查 Tracker URL 配置
# 编辑 relay_server.py
TRACKER_URL = "http://正确的IP:9000"

# 2. 确保 Tracker 服务器可访问
curl http://tracker-ip:9000/health

# 3. 检查防火墙
sudo ufw allow 9000/tcp
```

---

### 5. ❌ 数据传输缓慢或卡顿

#### 症状
- Minecraft 游戏内延迟高
- 区块加载慢
- 频繁超时

#### 优化建议

**1. 选择低延迟的中继服务器**
```
在"中继服务器"页面：
1. 点击"刷新列表"
2. 点击"测试延迟"
3. 选择延迟最低的服务器（< 50ms 最佳）
```

**2. 优化 Minecraft 服务器设置**
```properties
# server.properties
view-distance=8  # 降低视距
network-compression-threshold=256
max-tick-time=60000
```

**3. 使用有线网络**
- 避免使用 WiFi
- 使用以太网连接

**4. 关闭不必要的程序**
- 减少带宽占用
- 释放系统资源

---

### 6. ❌ 端口被占用

#### 症状
```
[ERROR] 端口 25565 已被占用
```

#### 解决方案
```bash
# 查找占用端口的进程
# macOS/Linux
lsof -i :25565

# 杀死进程
kill -9 <PID>

# 或者更改端口
# 在客户端设置中使用其他端口（如 25566）
```

---

## 📊 日志级别说明

### DEBUG 日志
```python
# 启用详细日志（用于调试）
logging.basicConfig(level=logging.DEBUG)
```

**输出示例：**
```
[DEBUG] 中继->MC服务器: 转发 1024 字节
[DEBUG] MC服务器->中继: 转发 2048 字节
[DEBUG] 从房主收到 512 字节，转发给 1 个客户端
```

### INFO 日志（默认）
```
[INFO] 房主已连接到中继服务器
[INFO] 客户端连接: ('IP', port) (ID: xxx)
[INFO] 已连接到本地 Minecraft 服务器
```

### WARNING 日志
```
[WARNING] 连接被重置
[WARNING] 房主未连接，无法转发数据
```

### ERROR 日志
```
[ERROR] 转发数据失败: Connection lost
[ERROR] 无法连接到本地 Minecraft 服务器
```

---

## 🔍 诊断工具

### 1. 网络连通性测试
```bash
# 测试到中继服务器的连接
ping 185.239.87.249

# 测试端口
telnet 185.239.87.249 25600

# 或使用 nc
nc -zv 185.239.87.249 25600
```

### 2. 查看实时日志
```bash
# 客户端日志
# 在 GUI 的"日志"选项卡中查看

# 中继服务器日志
# 直接在终端查看输出

# Tracker 日志
# 直接在终端查看输出
```

### 3. 抓包分析（高级）
```bash
# 使用 tcpdump 抓包
sudo tcpdump -i any -n port 25600 -w capture.pcap

# 使用 Wireshark 分析
# 打开 capture.pcap 文件
```

---

## 💡 性能优化建议

### 客户端优化
1. **关闭不必要的日志**
   - 将日志级别设置为 INFO 或 WARNING
   
2. **使用本地中继服务器**
   - 如果可能，在同一局域网内部署中继服务器

### 服务器优化
1. **增加系统资源**
   ```bash
   # 增加文件描述符限制
   ulimit -n 65536
   ```

2. **使用高性能网络**
   - 千兆网卡
   - 低延迟网络

3. **优化 Python 性能**
   ```bash
   # 使用 PyPy（可选）
   pypy3 relay_server.py
   ```

---

## 📞 获取帮助

如果问题仍然存在：

1. **收集日志**
   - 客户端日志
   - 中继服务器日志
   - Tracker 日志

2. **记录问题**
   - 具体的错误信息
   - 重现步骤
   - 系统环境

3. **检查版本**
   ```bash
   python3 --version
   pip list | grep aiohttp
   ```

---

## ✅ 成功连接的标志

### 房主端应该看到：
```
[INFO] 成功获取中继地址: 185.239.87.249:25600
[INFO] 房主已连接到中继服务器: 185.239.87.249:25600
[INFO] 等待客户端连接...
[INFO] 检测到客户端连接（收到 XXX 字节）
[INFO] 已连接到本地 Minecraft 服务器: 127.0.0.1:25565
[DEBUG] 中继->MC服务器: 转发 XXX 字节
[DEBUG] MC服务器->中继: 转发 XXX 字节
```

### 玩家端应该看到：
```
[INFO] 连接到中继服务器: 185.239.87.249:25600
[INFO] 本地服务器已启动: 127.0.0.1:25565
[INFO] 本地 Minecraft 连接: ('127.0.0.1', XXXXX)
[INFO] 已连接到中继服务器: 185.239.87.249:25600
[DEBUG] 本地->中继: 转发 XXX 字节
[DEBUG] 中继->本地: 转发 XXX 字节
```

### 中继服务器应该看到：
```
[INFO] 新连接: ('IP1', port) -> 端口 25600
[INFO] 房主连接: ('IP1', port)
[INFO] 新连接: ('IP2', port) -> 端口 25600
[INFO] 客户端连接: ('IP2', port) (ID: xxx)
[DEBUG] 从房主收到 XXX 字节，转发给 1 个客户端
[DEBUG] 从客户端 xxx 收到 XXX 字节
```

---

## 🎯 快速诊断流程图

```
连接失败？
    ↓
检查 MC 服务器是否运行？
    ├─ 否 → 启动 MC 服务器
    └─ 是 ↓
检查中继服务器是否可达？
    ├─ 否 → 检查网络/防火墙
    └─ 是 ↓
检查端口配置是否正确？
    ├─ 否 → 修改端口配置
    └─ 是 ↓
查看详细日志找出具体错误
```
