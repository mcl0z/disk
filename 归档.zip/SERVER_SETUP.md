# Minecraft P2P 服务器部署指南

本文档介绍如何部署和使用 Tracker 服务器和中继服务器。

## 📋 目录

- [系统架构](#系统架构)
- [环境要求](#环境要求)
- [快速开始](#快速开始)
- [详细配置](#详细配置)
- [API 文档](#api-文档)
- [故障排查](#故障排查)

---

## 🏗️ 系统架构

```
┌─────────────┐
│   Tracker   │  ← 管理中继服务器列表
│   Server    │
└──────┬──────┘
       │
       │ 注册/心跳
       │
┌──────▼──────┐     ┌──────────────┐
│   Relay     │     │    Relay     │
│  Server 1   │     │   Server 2   │  ← 转发游戏流量
└──────┬──────┘     └──────┬───────┘
       │                   │
       │ 流量转发          │ 流量转发
       │                   │
┌──────▼──────┐     ┌──────▼───────┐
│   房主      │     │   客户端     │
│ (Minecraft) │     │ (Minecraft)  │
└─────────────┘     └──────────────┘
```

### 工作流程

1. **中继服务器启动** → 自动向 Tracker 注册
2. **客户端请求** → 从 Tracker 获取中继服务器列表
3. **房主选择中继** → 请求开启转发会话
4. **获取地址** → 中继服务器返回可连接的地址和端口
5. **客户端连接** → 通过中继地址连接到房主
6. **流量转发** → 中继服务器在房主和客户端之间转发数据

---

## 💻 环境要求

### Python 版本
- Python 3.8 或更高版本

### 依赖库
```bash
pip install aiohttp
```

### 系统要求
- **Tracker 服务器**: 1 核 CPU, 512MB RAM
- **中继服务器**: 2 核 CPU, 1GB RAM (每 10 个会话)
- **网络**: 公网 IP 或端口转发配置

---

## 🚀 快速开始

### 1. 启动 Tracker 服务器

```bash
# 在服务器 A 上运行
python3 tracker_server.py
```

默认监听: `0.0.0.0:9000`

### 2. 启动中继服务器

```bash
# 在服务器 B 上运行
python3 relay_server.py
```

默认监听: `0.0.0.0:8888`

**注意**: 需要先修改 `relay_server.py` 中的 `TRACKER_URL` 为实际的 Tracker 地址。

### 3. 启动客户端

```bash
python3 Qt_Verison_Client.py
```

在客户端中：
1. 进入"设置"页面
2. 选择"代理模式"
3. 配置 Tracker 地址（如 `tracker.example.com:9000`）
4. 前往"中继服务器"页面，刷新列表
5. 选择一个服务器，返回主页启动连接

---

## ⚙️ 详细配置

### Tracker 服务器配置

编辑 `tracker_server.py`:

```python
# 监听配置
TRACKER_HOST = "0.0.0.0"  # 监听所有网卡
TRACKER_PORT = 9000       # 监听端口

# 心跳超时（秒）
heartbeat_timeout = 60
```

### 中继服务器配置

编辑 `relay_server.py`:

```python
# 服务器信息
RELAY_HOST = "0.0.0.0"
RELAY_PORT = 8888
RELAY_NAME = "Relay-Server-1"  # 服务器名称
RELAY_REGION = "Asia"          # 地区标识
MAX_CAPACITY = 100             # 最大会话数

# Tracker 地址
TRACKER_URL = "http://your-tracker-ip:9000"

# 端口池（用于分配给各个会话）
port_pool = range(25566, 25666)  # 100 个端口
```

### 防火墙配置

#### Tracker 服务器
```bash
# 开放 HTTP API 端口
sudo ufw allow 9000/tcp
```

#### 中继服务器
```bash
# 开放 HTTP API 端口
sudo ufw allow 8888/tcp

# 开放转发端口池
sudo ufw allow 25566:25666/tcp
```

---

## 📚 API 文档

### Tracker 服务器 API

#### 1. 获取中继服务器列表
```http
GET /api/relay-servers
```

**响应示例**:
```json
{
  "success": true,
  "count": 2,
  "servers": [
    {
      "name": "Relay-Server-1",
      "ip": "192.168.1.100",
      "port": 8888,
      "status": "online",
      "load": "5/100",
      "region": "Asia"
    }
  ]
}
```

#### 2. 注册中继服务器
```http
POST /api/register-relay
Content-Type: application/json

{
  "name": "My-Relay",
  "ip": "192.168.1.100",
  "port": 8888,
  "region": "Asia",
  "capacity": 100
}
```

#### 3. 发送心跳
```http
POST /api/heartbeat
Content-Type: application/json

{
  "relay_id": "192.168.1.100:8888",
  "current_load": 10
}
```

#### 4. 获取最佳服务器
```http
GET /api/best-server
```

### 中继服务器 API

#### 1. 请求中继会话
```http
POST /api/request-relay
Content-Type: application/json

{
  "room_id": "abc123",
  "mode": "host"
}
```

**响应示例**:
```json
{
  "success": true,
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "relay_address": "relay.example.com",
  "relay_port": 25566,
  "room_id": "abc123",
  "message": "中继会话已创建"
}
```

#### 2. 关闭会话
```http
POST /api/close-session
Content-Type: application/json

{
  "session_id": "550e8400-e29b-41d4-a716-446655440000"
}
```

#### 3. 获取会话列表
```http
GET /api/sessions
```

---

## 🔧 故障排查

### 问题 1: 中继服务器无法注册到 Tracker

**可能原因**:
- Tracker 服务器未启动
- 网络连接问题
- TRACKER_URL 配置错误

**解决方法**:
```bash
# 检查 Tracker 是否运行
curl http://tracker-ip:9000/health

# 检查网络连接
ping tracker-ip

# 查看中继服务器日志
# 日志会显示注册失败的详细信息
```

### 问题 2: 客户端无法获取服务器列表

**可能原因**:
- Tracker 地址配置错误
- 防火墙阻止连接
- 所有中继服务器都离线

**解决方法**:
```bash
# 测试 Tracker API
curl http://tracker-ip:9000/api/relay-servers

# 检查防火墙
sudo ufw status
```

### 问题 3: 流量转发失败

**可能原因**:
- 端口被占用
- 防火墙阻止端口
- 会话已过期

**解决方法**:
```bash
# 检查端口占用
netstat -tulpn | grep 25566

# 查看会话状态
curl http://relay-ip:8888/api/sessions

# 检查防火墙规则
sudo ufw status numbered
```

### 问题 4: 心跳超时

**可能原因**:
- 网络不稳定
- 中继服务器负载过高
- Tracker 服务器重启

**解决方法**:
- 增加心跳超时时间
- 优化中继服务器性能
- 重启中继服务器重新注册

---

## 📊 监控和维护

### 健康检查

```bash
# Tracker 健康检查
curl http://tracker-ip:9000/health

# 中继服务器健康检查
curl http://relay-ip:8888/health
```

### 日志查看

服务器会输出详细的日志信息，包括：
- 连接建立/断开
- 数据传输量
- 错误信息

### 性能监控

建议监控以下指标：
- CPU 使用率
- 内存使用率
- 网络带宽
- 活跃会话数
- 数据传输量

---

## 🔐 安全建议

1. **使用 HTTPS**: 在生产环境中，为 Tracker 和中继服务器配置 SSL/TLS
2. **访问控制**: 限制只有授权的中继服务器可以注册
3. **速率限制**: 防止 API 滥用
4. **日志审计**: 记录所有关键操作
5. **定期更新**: 保持依赖库和系统更新

---

## 📝 生产环境部署

### 使用 systemd 管理服务

创建 `/etc/systemd/system/tracker.service`:
```ini
[Unit]
Description=Minecraft P2P Tracker Server
After=network.target

[Service]
Type=simple
User=minecraft
WorkingDirectory=/opt/minecraft-p2p
ExecStart=/usr/bin/python3 /opt/minecraft-p2p/tracker_server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

启动服务:
```bash
sudo systemctl daemon-reload
sudo systemctl enable tracker
sudo systemctl start tracker
sudo systemctl status tracker
```

### 使用 Docker 部署

创建 `Dockerfile`:
```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY tracker_server.py .
COPY relay_server.py .

EXPOSE 9000 8888 25566-25666

CMD ["python3", "tracker_server.py"]
```

构建和运行:
```bash
docker build -t minecraft-p2p-tracker .
docker run -d -p 9000:9000 --name tracker minecraft-p2p-tracker
```

---

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 许可证

MIT License
