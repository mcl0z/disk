P2P minecraft
通过nat打洞沟通两个客户端达到联机的效果
优点是近距离低延迟 
