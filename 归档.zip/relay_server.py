#!/usr/bin/env python3
"""
中继服务器 (Relay Server)
用于转发 Minecraft 游戏流量
"""

import asyncio
import json
import logging
import socket
import uuid
from aiohttp import web
from typing import Dict, Optional
import time
import aiohttp

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)

# 中继服务器配置
RELAY_HOST = "0.0.0.0"
RELAY_PORT = 8888
RELAY_NAME = "Relay-Server-1"
RELAY_REGION = "Asia"
MAX_CAPACITY = 100

# Tracker 服务器配置
TRACKER_URL = "http://124.71.76.131:9000"

class RelaySession:
    """中继会话"""
    def __init__(self, session_id: str, room_id: str, host_port: int):
        self.session_id = session_id
        self.room_id = room_id
        self.host_port = host_port  # 分配给房主的端口
        self.host_connected = False
        self.clients: Dict[str, asyncio.StreamWriter] = {}  # client_id -> writer
        self.host_writer: Optional[asyncio.StreamWriter] = None
        self.host_reader: Optional[asyncio.StreamReader] = None
        self.created_at = time.time()
        self.bytes_transferred = 0
        self.host_last_disconnect_time: Optional[float] = None  # 房主最后断开时间
        self.cleanup_task: Optional[asyncio.Task] = None  # 清理任务
        self.tcp_server: Optional[asyncio.Server] = None  # TCP 服务器实例
        
    def add_client(self, client_id: str, writer: asyncio.StreamWriter):
        """添加客户端连接"""
        self.clients[client_id] = writer
        logging.info(f"会话 {self.session_id}: 客户端 {client_id} 已连接")
    
    def remove_client(self, client_id: str):
        """移除客户端连接"""
        if client_id in self.clients:
            del self.clients[client_id]
            logging.info(f"会话 {self.session_id}: 客户端 {client_id} 已断开")
    
    def set_host(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        """设置房主连接"""
        self.host_reader = reader
        self.host_writer = writer
        self.host_connected = True
        
        # 取消清理任务（如果存在）
        if self.cleanup_task and not self.cleanup_task.done():
            self.cleanup_task.cancel()
            logging.info(f"会话 {self.session_id}: 房主重新连接，已取消清理任务")
        
        self.host_last_disconnect_time = None
        logging.info(f"会话 {self.session_id}: 房主已连接")

class RelayServer:
    def __init__(self, name: str, region: str, capacity: int):
        self.name = name
        self.region = region
        self.capacity = capacity
        self.sessions: Dict[str, RelaySession] = {}  # session_id -> RelaySession
        self.port_pool = set()  # 可用端口池，初始为空，通过扫描填充
        self.allocated_ports: Dict[int, str] = {}  # port -> session_id
        self.relay_id = None
        self.public_ip = None  # 存储公网 IP
        self.heartbeat_task = None
        
        # 初始扫描端口
        self.scan_ports()
        
    def is_port_bindable(self, port: int) -> bool:
        """检查端口是否可绑定"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                # 设置 SO_REUSEADDR 以避免 TIME_WAIT 状态导致的误判
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                s.bind(('0.0.0.0', port))
                return True
        except OSError:
            return False

    def scan_ports(self):
        """扫描并更新可用端口池"""
        logging.info("正在扫描可用端口...")
        # 扫描范围 25566-25666
        found_count = 0
        for port in range(25566, 25666):
            if port not in self.allocated_ports:
                if self.is_port_bindable(port):
                    self.port_pool.add(port)
                    found_count += 1
        
        logging.info(f"扫描完成，当前可用端口数: {len(self.port_pool)}")
        
    def allocate_port(self) -> Optional[int]:
        """分配一个可用端口"""
        # 如果池为空，尝试重新扫描
        if not self.port_pool:
            logging.info("端口池为空，尝试重新扫描...")
            self.scan_ports()
            
        # 尝试获取端口
        while self.port_pool:
            port = self.port_pool.pop()
            # 二次检查端口是否仍可用
            if self.is_port_bindable(port):
                return port
            else:
                logging.warning(f"端口 {port} 似乎已被占用，尝试下一个...")
        
        logging.warning("无可用端口")
        return None
    
    def release_port(self, port: int):
        """释放端口"""
        if port in self.allocated_ports:
            del self.allocated_ports[port]
        self.port_pool.add(port)
    
    def create_session(self, room_id: str) -> Optional[RelaySession]:
        """创建中继会话"""
        if len(self.sessions) >= self.capacity:
            logging.warning("服务器已达到最大容量")
            return None
        
        port = self.allocate_port()
        if not port:
            logging.error("无可用端口")
            return None
        
        session_id = str(uuid.uuid4())
        session = RelaySession(session_id, room_id, port)
        self.sessions[session_id] = session
        self.allocated_ports[port] = session_id
        
        logging.info(f"创建会话: {session_id}, 房间ID: {room_id}, 端口: {port}")
        return session
    
    def get_session(self, session_id: str) -> Optional[RelaySession]:
        """获取会话"""
        return self.sessions.get(session_id)
    
    def get_session_by_port(self, port: int) -> Optional[RelaySession]:
        """通过端口获取会话"""
        session_id = self.allocated_ports.get(port)
        if session_id:
            return self.sessions.get(session_id)
        return None
    
    async def remove_session(self, session_id: str):
        """移除会话"""
        if session_id in self.sessions:
            session = self.sessions[session_id]
            
            # 关闭 TCP 服务器
            if session.tcp_server:
                session.tcp_server.close()
                await session.tcp_server.wait_closed()
                logging.info(f"已关闭会话 {session_id} 的 TCP 服务器（端口 {session.host_port}）")
            
            # 取消清理任务
            if session.cleanup_task and not session.cleanup_task.done():
                session.cleanup_task.cancel()
            
            self.release_port(session.host_port)
            del self.sessions[session_id]
            logging.info(f"移除会话: {session_id}")
    
    def get_current_load(self) -> int:
        """获取当前负载"""
        return len(self.sessions)
    
    async def register_to_tracker(self):
        """向 Tracker 注册"""
        try:
            # 不发送 IP，让 Tracker 从请求中获取真实 IP
            async with aiohttp.ClientSession() as session:
                data = {
                    "name": self.name,
                    "port": RELAY_PORT,
                    "region": self.region,
                    "capacity": self.capacity,
                    "current_load": 0
                }
                
                async with session.post(f"{TRACKER_URL}/api/register-relay", json=data) as resp:
                    if resp.status == 200:
                        result = await resp.json()
                        self.relay_id = result.get("relay_id")
                        self.public_ip = result.get("registered_ip")  # 保存公网 IP
                        logging.info(f"成功注册到 Tracker: {self.relay_id}")
                        logging.info(f"注册的公网 IP: {self.public_ip}")
                        return True
                    else:
                        logging.error(f"注册失败: HTTP {resp.status}")
                        return False
        except Exception as e:
            logging.error(f"注册到 Tracker 失败: {e}")
            return False
    
    async def send_heartbeat(self):
        """发送心跳到 Tracker"""
        while True:
            try:
                await asyncio.sleep(30)  # 每30秒发送一次心跳
                
                if not self.relay_id:
                    continue
                
                async with aiohttp.ClientSession() as session:
                    data = {
                        "relay_id": self.relay_id,
                        "current_load": self.get_current_load()
                    }
                    
                    async with session.post(f"{TRACKER_URL}/api/heartbeat", json=data) as resp:
                        if resp.status == 200:
                            logging.debug("心跳发送成功")
                        else:
                            logging.warning(f"心跳发送失败: HTTP {resp.status}")
            except Exception as e:
                logging.error(f"发送心跳失败: {e}")
    
    async def unregister_from_tracker(self):
        """从 Tracker 注销"""
        if not self.relay_id:
            return
        
        try:
            async with aiohttp.ClientSession() as session:
                data = {"relay_id": self.relay_id}
                async with session.post(f"{TRACKER_URL}/api/unregister-relay", json=data) as resp:
                    if resp.status == 200:
                        logging.info("成功从 Tracker 注销")
        except Exception as e:
            logging.error(f"从 Tracker 注销失败: {e}")

# 创建全局中继服务器实例
relay_server = RelayServer(RELAY_NAME, RELAY_REGION, MAX_CAPACITY)

# ==================== TCP 流量转发 ====================

async def handle_host_connection(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, session: RelaySession):
    """处理房主连接，转发数据到所有客户端"""
    addr = writer.get_extra_info('peername')
    logging.info(f"房主连接: {addr}")
    
    session.set_host(reader, writer)
    
    try:
        while True:
            try:
                # 使用 8KB 缓冲区，逐包读取和转发
                data = await reader.read(8192)
                if not data:
                    logging.info("房主连接已关闭 (EOF)")
                    break
                
                logging.debug(f"从房主收到 {len(data)} 字节，转发给 {len(session.clients)} 个客户端")
                
                # 转发给所有客户端
                disconnected_clients = []
                for client_id, client_writer in list(session.clients.items()):
                    try:
                        if client_writer.is_closing():
                            disconnected_clients.append(client_id)
                            continue
                            
                        client_writer.write(data)
                        await client_writer.drain()
                        session.bytes_transferred += len(data)
                    except (ConnectionResetError, BrokenPipeError) as e:
                        logging.warning(f"客户端 {client_id} 连接已断开: {e}")
                        disconnected_clients.append(client_id)
                    except Exception as e:
                        logging.error(f"转发数据到客户端 {client_id} 失败: {e}")
                        disconnected_clients.append(client_id)
                
                # 清理断开的客户端
                for client_id in disconnected_clients:
                    session.remove_client(client_id)
                    
            except (ConnectionResetError, BrokenPipeError) as e:
                logging.warning(f"房主连接异常: {e}")
                break
            except Exception as e:
                logging.error(f"处理房主数据时出错: {e}")
                await asyncio.sleep(0.1)
                continue
                
    except ConnectionResetError:
        logging.warning(f"房主连接被重置: {addr}")
    except Exception as e:
        logging.error(f"房主连接错误: {e}")
        import traceback
        logging.error(traceback.format_exc())
    finally:
        logging.info(f"房主断开连接: {addr}")
        
        # 标记房主为未连接状态，但不立即释放会话
        # 这允许房主重新连接以处理下一个客户端
        session.host_connected = False
        session.host_writer = None
        session.host_reader = None
        session.host_last_disconnect_time = time.time()
        
        # 启动清理任务：如果30秒内房主不重连，则释放会话
        async def cleanup_if_not_reconnected():
            await asyncio.sleep(30)
            if session.session_id in relay_server.sessions and not session.host_connected:
                logging.warning(f"房主30秒未重连，自动释放会话 {session.session_id} 和端口 {session.host_port}")
                await relay_server.remove_session(session.session_id)
        
        session.cleanup_task = asyncio.create_task(cleanup_if_not_reconnected())
        logging.info(f"会话 {session.session_id} 的房主已断开，等待重新连接（30秒超时）...")
            
        try:
            if not writer.is_closing():
                writer.close()
                await writer.wait_closed()
        except:
            pass

async def handle_client_connection(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, session: RelaySession):
    """处理客户端连接，转发数据到房主"""
    addr = writer.get_extra_info('peername')
    client_id = str(uuid.uuid4())[:8]
    logging.info(f"客户端连接: {addr} (ID: {client_id})")
    
    session.add_client(client_id, writer)
    
    wait_start_time = 0  # 开始等待房主的时间
    
    try:
        while True:
            try:
                # 使用 8KB 缓冲区，逐包读取和转发
                data = await reader.read(8192)
                if not data:
                    logging.info(f"客户端 {client_id} 连接已关闭 (EOF)")
                    break
                
                logging.debug(f"从客户端 {client_id} 收到 {len(data)} 字节")
                
                # 转发给房主
                if session.host_writer and not session.host_writer.is_closing():
                    wait_start_time = 0  # 重置等待时间
                    try:
                        session.host_writer.write(data)
                        await session.host_writer.drain()
                        session.bytes_transferred += len(data)
                    except (ConnectionResetError, BrokenPipeError) as e:
                        logging.warning(f"房主连接已断开: {e}")
                        break
                    except Exception as e:
                        logging.error(f"转发数据到房主失败: {e}")
                        break
                else:
                    # 检查会话是否有效
                    if session.session_id not in relay_server.sessions:
                        logging.warning(f"会话 {session.session_id} 已失效，断开客户端 {client_id}")
                        break
                        
                    # 检查超时
                    if wait_start_time == 0:
                        wait_start_time = time.time()
                    elif time.time() - wait_start_time > 10:
                        logging.warning(f"等待房主连接超时(10秒)，断开客户端 {client_id}")
                        break
                        
                    logging.warning(f"房主未连接，等待房主...")
                    await asyncio.sleep(1.0)  # 每秒检查一次，避免日志刷屏
                    continue
                    
            except (ConnectionResetError, BrokenPipeError) as e:
                logging.warning(f"客户端 {client_id} 连接异常: {e}")
                await asyncio.sleep(0.1)
                continue
            except Exception as e:
                logging.error(f"处理客户端 {client_id} 数据时出错: {e}")
                await asyncio.sleep(0.1)
                continue
                
    except ConnectionResetError:
        logging.warning(f"客户端 {client_id} 连接被重置: {addr}")
    except Exception as e:
        logging.error(f"客户端连接错误: {e}")
        import traceback
        logging.error(traceback.format_exc())
    finally:
        logging.info(f"客户端断开连接: {addr}")
        session.remove_client(client_id)
        try:
            if not writer.is_closing():
                writer.close()
                await writer.wait_closed()
        except:
            pass

async def tcp_server_handler(reader: asyncio.StreamReader, writer: asyncio.StreamReader):
    """TCP 服务器处理器"""
    addr = writer.get_extra_info('peername')
    sockname = writer.get_extra_info('sockname')
    port = sockname[1]
    
    logging.info(f"新连接: {addr} -> 端口 {port}")
    
    # 根据端口找到对应的会话
    session = relay_server.get_session_by_port(port)
    
    if not session:
        logging.warning(f"端口 {port} 没有对应的会话")
        writer.close()
        await writer.wait_closed()
        return
    
    # 判断是房主还是客户端
    # 第一个连接的是房主，后续连接的是客户端
    if not session.host_connected:
        await handle_host_connection(reader, writer, session)
    else:
        await handle_client_connection(reader, writer, session)

# ==================== HTTP API 路由 ====================

async def handle_request_relay(request):
    """API: 请求中继会话"""
    try:
        data = await request.json()
        room_id = data.get("room_id")
        mode = data.get("mode", "host")
        
        if not room_id:
            return web.json_response({
                "success": False,
                "error": "缺少 room_id"
            }, status=400)
        
        # 创建会话
        session = relay_server.create_session(room_id)
        
        if not session:
            return web.json_response({
                "success": False,
                "error": "无法创建会话，服务器已满或无可用端口"
            }, status=503)
        
        # 启动 TCP 服务器监听分配的端口（绑定到 0.0.0.0 以接受所有连接）
        server = await asyncio.start_server(
            tcp_server_handler,
            "0.0.0.0",  # 监听所有网卡
            session.host_port
        )
        
        # 保存 TCP 服务器实例到会话中
        session.tcp_server = server
        
        # 使用注册时获取的公网 IP
        relay_address = relay_server.public_ip or "unknown"
        
        logging.info(f"为会话 {session.session_id} 启动 TCP 服务器: 0.0.0.0:{session.host_port}")
        logging.info(f"客户端应连接到: {relay_address}:{session.host_port}")
        
        return web.json_response({
            "success": True,
            "session_id": session.session_id,
            "relay_address": relay_address,
            "relay_port": session.host_port,
            "room_id": room_id,
            "message": "中继会话已创建，请连接到指定地址和端口"
        })
    except Exception as e:
        logging.error(f"请求中继会话失败: {e}")
        import traceback
        logging.error(traceback.format_exc())
        return web.json_response({
            "success": False,
            "error": str(e)
        }, status=500)

async def handle_close_session(request):
    """API: 关闭中继会话"""
    try:
        data = await request.json()
        session_id = data.get("session_id")
        
        if not session_id:
            return web.json_response({
                "success": False,
                "error": "缺少 session_id"
            }, status=400)
        
        await relay_server.remove_session(session_id)
        
        return web.json_response({
            "success": True,
            "message": "会话已关闭"
        })
    except Exception as e:
        logging.error(f"关闭会话失败: {e}")
        return web.json_response({
            "success": False,
            "error": str(e)
        }, status=500)

async def handle_get_sessions(request):
    """API: 获取所有会话"""
    try:
        sessions_info = []
        for session_id, session in relay_server.sessions.items():
            sessions_info.append({
                "session_id": session_id,
                "room_id": session.room_id,
                "host_port": session.host_port,
                "host_connected": session.host_connected,
                "clients_count": len(session.clients),
                "bytes_transferred": session.bytes_transferred,
                "uptime": int(time.time() - session.created_at)
            })
        
        return web.json_response({
            "success": True,
            "count": len(sessions_info),
            "sessions": sessions_info
        })
    except Exception as e:
        logging.error(f"获取会话列表失败: {e}")
        return web.json_response({
            "success": False,
            "error": str(e)
        }, status=500)

async def handle_health(request):
    """健康检查"""
    return web.json_response({
        "status": "healthy",
        "service": "Relay Server",
        "name": relay_server.name,
        "current_load": relay_server.get_current_load(),
        "capacity": relay_server.capacity
    })

# ==================== 主程序 ====================

def create_app():
    """创建 Web 应用"""
    app = web.Application()
    
    # 添加路由
    app.router.add_post('/api/request-relay', handle_request_relay)
    app.router.add_post('/api/close-session', handle_close_session)
    app.router.add_get('/api/sessions', handle_get_sessions)
    app.router.add_get('/health', handle_health)
    
    # 添加 CORS 支持
    async def cors_middleware(app, handler):
        async def middleware_handler(request):
            if request.method == 'OPTIONS':
                response = web.Response()
            else:
                response = await handler(request)
            
            response.headers['Access-Control-Allow-Origin'] = '*'
            response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
            response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
            return response
        return middleware_handler
    
    app.middlewares.append(cors_middleware)
    
    return app

async def startup_tasks():
    """启动任务"""
    # 注册到 Tracker
    await relay_server.register_to_tracker()
    
    # 启动心跳任务
    relay_server.heartbeat_task = asyncio.create_task(relay_server.send_heartbeat())

async def shutdown_tasks():
    """关闭任务"""
    # 取消心跳任务
    if relay_server.heartbeat_task:
        relay_server.heartbeat_task.cancel()
    
    # 从 Tracker 注销
    await relay_server.unregister_from_tracker()

def main():
    """启动中继服务器"""
    logging.info("=" * 60)
    logging.info("Minecraft P2P 中继服务器")
    logging.info("=" * 60)
    logging.info(f"服务器名称: {RELAY_NAME}")
    logging.info(f"监听地址: {RELAY_HOST}:{RELAY_PORT}")
    logging.info(f"最大容量: {MAX_CAPACITY} 个会话")
    logging.info(f"Tracker 地址: {TRACKER_URL}")
    logging.info("API 端点:")
    logging.info("  POST /api/request-relay  - 请求中继会话")
    logging.info("  POST /api/close-session  - 关闭会话")
    logging.info("  GET  /api/sessions       - 获取会话列表")
    logging.info("  GET  /health             - 健康检查")
    logging.info("=" * 60)
    
    app = create_app()
    
    # 设置启动和关闭回调
    app.on_startup.append(lambda app: startup_tasks())
    app.on_shutdown.append(lambda app: shutdown_tasks())
    
    # 启动 Web 服务器
    web.run_app(app, host=RELAY_HOST, port=RELAY_PORT)

if __name__ == "__main__":
    main()
