#!/usr/bin/env python3
"""
服务器功能测试脚本
用于测试 Tracker 和中继服务器的基本功能
"""

import asyncio
import aiohttp
import json
import sys

# 配置
TRACKER_URL = "http://localhost:9000"
RELAY_URL = "http://localhost:8888"

class ServerTester:
    def __init__(self):
        self.passed = 0
        self.failed = 0
    
    def print_test(self, name: str):
        """打印测试名称"""
        print(f"\n{'='*60}")
        print(f"测试: {name}")
        print('='*60)
    
    def print_result(self, success: bool, message: str):
        """打印测试结果"""
        if success:
            print(f"✅ 通过: {message}")
            self.passed += 1
        else:
            print(f"❌ 失败: {message}")
            self.failed += 1
    
    def print_summary(self):
        """打印测试总结"""
        print(f"\n{'='*60}")
        print(f"测试总结")
        print('='*60)
        print(f"通过: {self.passed}")
        print(f"失败: {self.failed}")
        print(f"总计: {self.passed + self.failed}")
        print('='*60)
        
        if self.failed == 0:
            print("🎉 所有测试通过！")
            return 0
        else:
            print("⚠️  部分测试失败")
            return 1

tester = ServerTester()

async def test_tracker_health():
    """测试 Tracker 健康检查"""
    tester.print_test("Tracker 健康检查")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{TRACKER_URL}/health") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    tester.print_result(True, f"Tracker 运行正常: {data}")
                    return True
                else:
                    tester.print_result(False, f"HTTP 状态码: {resp.status}")
                    return False
    except Exception as e:
        tester.print_result(False, f"连接失败: {e}")
        return False

async def test_relay_health():
    """测试中继服务器健康检查"""
    tester.print_test("中继服务器健康检查")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{RELAY_URL}/health") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    tester.print_result(True, f"中继服务器运行正常: {data}")
                    return True
                else:
                    tester.print_result(False, f"HTTP 状态码: {resp.status}")
                    return False
    except Exception as e:
        tester.print_result(False, f"连接失败: {e}")
        return False

async def test_register_relay():
    """测试中继服务器注册"""
    tester.print_test("中继服务器注册")
    
    try:
        async with aiohttp.ClientSession() as session:
            data = {
                "name": "Test-Relay",
                "ip": "127.0.0.1",
                "port": 9999,
                "region": "Test",
                "capacity": 10
            }
            
            async with session.post(f"{TRACKER_URL}/api/register-relay", json=data) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    relay_id = result.get("relay_id")
                    tester.print_result(True, f"注册成功: {relay_id}")
                    return relay_id
                else:
                    tester.print_result(False, f"HTTP 状态码: {resp.status}")
                    return None
    except Exception as e:
        tester.print_result(False, f"注册失败: {e}")
        return None

async def test_get_relay_servers():
    """测试获取中继服务器列表"""
    tester.print_test("获取中继服务器列表")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{TRACKER_URL}/api/relay-servers") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    servers = data.get("servers", [])
                    tester.print_result(True, f"获取到 {len(servers)} 个服务器")
                    
                    for server in servers:
                        print(f"  - {server['name']}: {server['ip']}:{server['port']} ({server['status']})")
                    
                    return servers
                else:
                    tester.print_result(False, f"HTTP 状态码: {resp.status}")
                    return []
    except Exception as e:
        tester.print_result(False, f"获取失败: {e}")
        return []

async def test_heartbeat(relay_id: str):
    """测试心跳"""
    tester.print_test("发送心跳")
    
    if not relay_id:
        tester.print_result(False, "没有可用的 relay_id")
        return False
    
    try:
        async with aiohttp.ClientSession() as session:
            data = {
                "relay_id": relay_id,
                "current_load": 5
            }
            
            async with session.post(f"{TRACKER_URL}/api/heartbeat", json=data) as resp:
                if resp.status == 200:
                    tester.print_result(True, "心跳发送成功")
                    return True
                else:
                    tester.print_result(False, f"HTTP 状态码: {resp.status}")
                    return False
    except Exception as e:
        tester.print_result(False, f"心跳失败: {e}")
        return False

async def test_request_relay_session():
    """测试请求中继会话"""
    tester.print_test("请求中继会话")
    
    try:
        async with aiohttp.ClientSession() as session:
            data = {
                "room_id": "test-room-123",
                "mode": "host"
            }
            
            async with session.post(f"{RELAY_URL}/api/request-relay", json=data) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    session_id = result.get("session_id")
                    relay_port = result.get("relay_port")
                    tester.print_result(True, f"会话创建成功: {session_id}, 端口: {relay_port}")
                    return session_id
                else:
                    tester.print_result(False, f"HTTP 状态码: {resp.status}")
                    return None
    except Exception as e:
        tester.print_result(False, f"请求失败: {e}")
        return None

async def test_get_sessions():
    """测试获取会话列表"""
    tester.print_test("获取会话列表")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{RELAY_URL}/api/sessions") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    sessions = data.get("sessions", [])
                    tester.print_result(True, f"获取到 {len(sessions)} 个会话")
                    
                    for sess in sessions:
                        print(f"  - {sess['session_id'][:8]}: 房间 {sess['room_id']}, 端口 {sess['host_port']}")
                    
                    return sessions
                else:
                    tester.print_result(False, f"HTTP 状态码: {resp.status}")
                    return []
    except Exception as e:
        tester.print_result(False, f"获取失败: {e}")
        return []

async def test_close_session(session_id: str):
    """测试关闭会话"""
    tester.print_test("关闭会话")
    
    if not session_id:
        tester.print_result(False, "没有可用的 session_id")
        return False
    
    try:
        async with aiohttp.ClientSession() as session:
            data = {"session_id": session_id}
            
            async with session.post(f"{RELAY_URL}/api/close-session", json=data) as resp:
                if resp.status == 200:
                    tester.print_result(True, "会话关闭成功")
                    return True
                else:
                    tester.print_result(False, f"HTTP 状态码: {resp.status}")
                    return False
    except Exception as e:
        tester.print_result(False, f"关闭失败: {e}")
        return False

async def test_unregister_relay(relay_id: str):
    """测试注销中继服务器"""
    tester.print_test("注销中继服务器")
    
    if not relay_id:
        tester.print_result(False, "没有可用的 relay_id")
        return False
    
    try:
        async with aiohttp.ClientSession() as session:
            data = {"relay_id": relay_id}
            
            async with session.post(f"{TRACKER_URL}/api/unregister-relay", json=data) as resp:
                if resp.status == 200:
                    tester.print_result(True, "注销成功")
                    return True
                else:
                    tester.print_result(False, f"HTTP 状态码: {resp.status}")
                    return False
    except Exception as e:
        tester.print_result(False, f"注销失败: {e}")
        return False

async def test_get_best_server():
    """测试获取最佳服务器"""
    tester.print_test("获取最佳服务器")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{TRACKER_URL}/api/best-server") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    server = data.get("server")
                    if server:
                        tester.print_result(True, f"最佳服务器: {server['name']} ({server['ip']}:{server['port']})")
                    else:
                        tester.print_result(False, "没有可用的服务器")
                    return server
                elif resp.status == 404:
                    tester.print_result(True, "没有可用的服务器（预期结果）")
                    return None
                else:
                    tester.print_result(False, f"HTTP 状态码: {resp.status}")
                    return None
    except Exception as e:
        tester.print_result(False, f"获取失败: {e}")
        return None

async def run_all_tests():
    """运行所有测试"""
    print("\n" + "="*60)
    print("Minecraft P2P 服务器功能测试")
    print("="*60)
    print(f"Tracker URL: {TRACKER_URL}")
    print(f"Relay URL: {RELAY_URL}")
    print("="*60)
    
    # 测试 Tracker
    await test_tracker_health()
    
    # 测试中继服务器
    await test_relay_health()
    
    # 测试注册
    relay_id = await test_register_relay()
    
    # 测试获取服务器列表
    await test_get_relay_servers()
    
    # 测试心跳
    await test_heartbeat(relay_id)
    
    # 测试获取最佳服务器
    await test_get_best_server()
    
    # 测试请求会话
    session_id = await test_request_relay_session()
    
    # 测试获取会话列表
    await test_get_sessions()
    
    # 测试关闭会话
    await test_close_session(session_id)
    
    # 测试注销
    await test_unregister_relay(relay_id)
    
    # 打印总结
    return tester.print_summary()

def main():
    """主函数"""
    try:
        exit_code = asyncio.run(run_all_tests())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n测试被中断")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n测试出错: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
