#!/usr/bin/env python3
"""
Tracker 服务器
用于管理和分发中继服务器列表
"""

import asyncio
import json
import logging
from aiohttp import web
from typing import Dict, List
import time
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)

# Tracker 服务器配置
TRACKER_HOST = "0.0.0.0"
TRACKER_PORT = 9000

class TrackerServer:
    def __init__(self):
        self.relay_servers: Dict[str, dict] = {}  # relay_id -> server_info
        self.heartbeat_timeout = 60  # 心跳超时时间（秒）
        
    def add_relay_server(self, server_info: dict) -> str:
        """注册一个中继服务器"""
        relay_id = f"{server_info['ip']}:{server_info['port']}"
        
        self.relay_servers[relay_id] = {
            "id": relay_id,
            "name": server_info.get("name", f"Relay-{relay_id}"),
            "ip": server_info["ip"],
            "port": server_info["port"],
            "status": "online",
            "capacity": server_info.get("capacity", 100),  # 最大连接数
            "current_load": server_info.get("current_load", 0),  # 当前负载
            "region": server_info.get("region", "unknown"),
            "last_heartbeat": time.time(),
            "registered_at": datetime.now().isoformat()
        }
        
        logging.info(f"注册中继服务器: {relay_id} ({server_info.get('name')})")
        return relay_id
    
    def update_heartbeat(self, relay_id: str, load: int = None):
        """更新服务器心跳"""
        if relay_id in self.relay_servers:
            self.relay_servers[relay_id]["last_heartbeat"] = time.time()
            self.relay_servers[relay_id]["status"] = "online"
            
            if load is not None:
                self.relay_servers[relay_id]["current_load"] = load
            
            logging.debug(f"更新心跳: {relay_id}")
            return True
        return False
    
    def remove_relay_server(self, relay_id: str):
        """移除中继服务器"""
        if relay_id in self.relay_servers:
            del self.relay_servers[relay_id]
            logging.info(f"移除中继服务器: {relay_id}")
            return True
        return False
    
    def get_active_servers(self) -> List[dict]:
        """获取所有活跃的中继服务器"""
        current_time = time.time()
        active_servers = []
        
        # 清理超时的服务器
        expired_servers = []
        for relay_id, server in self.relay_servers.items():
            if current_time - server["last_heartbeat"] > self.heartbeat_timeout:
                server["status"] = "offline"
                expired_servers.append(relay_id)
            elif server["status"] == "online":
                # 只返回在线且未超时的服务器
                active_servers.append({
                    "name": server["name"],
                    "ip": server["ip"],
                    "port": server["port"],
                    "status": server["status"],
                    "load": f"{server['current_load']}/{server['capacity']}",
                    "region": server["region"]
                })
        
        # 移除过期服务器
        for relay_id in expired_servers:
            logging.warning(f"服务器心跳超时，标记为离线: {relay_id}")
        
        # 按负载排序（负载低的优先）
        active_servers.sort(key=lambda x: int(x["load"].split("/")[0]))
        
        return active_servers
    
    def get_best_server(self) -> dict:
        """获取负载最低的服务器"""
        active_servers = self.get_active_servers()
        if active_servers:
            return active_servers[0]
        return None

# 创建全局 Tracker 实例
tracker = TrackerServer()

# ==================== HTTP API 路由 ====================

async def handle_get_relay_servers(request):
    """API: 获取中继服务器列表"""
    try:
        servers = tracker.get_active_servers()
        
        return web.json_response({
            "success": True,
            "count": len(servers),
            "servers": servers
        })
    except Exception as e:
        logging.error(f"获取服务器列表失败: {e}")
        return web.json_response({
            "success": False,
            "error": str(e)
        }, status=500)

async def handle_register_relay(request):
    """API: 注册中继服务器"""
    try:
        data = await request.json()
        
        # 验证必需字段
        if "port" not in data:
            return web.json_response({
                "success": False,
                "error": "缺少必需字段: port"
            }, status=400)
        
        # 从请求中获取真实的客户端 IP
        # 优先使用 X-Forwarded-For（如果有反向代理）
        client_ip = request.headers.get('X-Forwarded-For')
        if client_ip:
            # X-Forwarded-For 可能包含多个 IP，取第一个
            client_ip = client_ip.split(',')[0].strip()
        else:
            # 直接从连接中获取 IP
            peername = request.transport.get_extra_info('peername')
            if peername:
                client_ip = peername[0]
            else:
                client_ip = "unknown"
        
        # 将获取到的 IP 添加到数据中
        data["ip"] = client_ip
        
        relay_id = tracker.add_relay_server(data)
        
        logging.info(f"中继服务器注册: {relay_id} (来自 {client_ip})")
        
        return web.json_response({
            "success": True,
            "relay_id": relay_id,
            "registered_ip": client_ip,
            "message": "中继服务器注册成功"
        })
    except Exception as e:
        logging.error(f"注册中继服务器失败: {e}")
        return web.json_response({
            "success": False,
            "error": str(e)
        }, status=500)

async def handle_heartbeat(request):
    """API: 中继服务器心跳"""
    try:
        data = await request.json()
        relay_id = data.get("relay_id")
        current_load = data.get("current_load")
        
        if not relay_id:
            return web.json_response({
                "success": False,
                "error": "缺少 relay_id"
            }, status=400)
        
        success = tracker.update_heartbeat(relay_id, current_load)
        
        if success:
            return web.json_response({
                "success": True,
                "message": "心跳更新成功"
            })
        else:
            return web.json_response({
                "success": False,
                "error": "服务器未注册"
            }, status=404)
    except Exception as e:
        logging.error(f"心跳更新失败: {e}")
        return web.json_response({
            "success": False,
            "error": str(e)
        }, status=500)

async def handle_unregister_relay(request):
    """API: 注销中继服务器"""
    try:
        data = await request.json()
        relay_id = data.get("relay_id")
        
        if not relay_id:
            return web.json_response({
                "success": False,
                "error": "缺少 relay_id"
            }, status=400)
        
        success = tracker.remove_relay_server(relay_id)
        
        if success:
            return web.json_response({
                "success": True,
                "message": "中继服务器注销成功"
            })
        else:
            return web.json_response({
                "success": False,
                "error": "服务器未找到"
            }, status=404)
    except Exception as e:
        logging.error(f"注销中继服务器失败: {e}")
        return web.json_response({
            "success": False,
            "error": str(e)
        }, status=500)

async def handle_get_best_server(request):
    """API: 获取最佳服务器（负载最低）"""
    try:
        best_server = tracker.get_best_server()
        
        if best_server:
            return web.json_response({
                "success": True,
                "server": best_server
            })
        else:
            return web.json_response({
                "success": False,
                "error": "没有可用的中继服务器"
            }, status=404)
    except Exception as e:
        logging.error(f"获取最佳服务器失败: {e}")
        return web.json_response({
            "success": False,
            "error": str(e)
        }, status=500)

async def handle_health(request):
    """健康检查"""
    return web.json_response({
        "status": "healthy",
        "service": "Tracker Server",
        "active_relays": len(tracker.get_active_servers())
    })

# ==================== 主程序 ====================

def create_app():
    """创建 Web 应用"""
    app = web.Application()
    
    # 添加路由
    app.router.add_get('/api/relay-servers', handle_get_relay_servers)
    app.router.add_post('/api/register-relay', handle_register_relay)
    app.router.add_post('/api/heartbeat', handle_heartbeat)
    app.router.add_post('/api/unregister-relay', handle_unregister_relay)
    app.router.add_get('/api/best-server', handle_get_best_server)
    app.router.add_get('/health', handle_health)
    
    # 添加 CORS 支持
    async def cors_middleware(app, handler):
        async def middleware_handler(request):
            if request.method == 'OPTIONS':
                response = web.Response()
            else:
                response = await handler(request)
            
            response.headers['Access-Control-Allow-Origin'] = '*'
            response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
            response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
            return response
        return middleware_handler
    
    app.middlewares.append(cors_middleware)
    
    return app

async def cleanup_task():
    """定期清理过期服务器"""
    while True:
        await asyncio.sleep(30)  # 每30秒检查一次
        tracker.get_active_servers()  # 这会触发清理逻辑

def main():
    """启动 Tracker 服务器"""
    logging.info("=" * 60)
    logging.info("Minecraft P2P Tracker 服务器")
    logging.info("=" * 60)
    logging.info(f"监听地址: {TRACKER_HOST}:{TRACKER_PORT}")
    logging.info("API 端点:")
    logging.info("  GET  /api/relay-servers     - 获取中继服务器列表")
    logging.info("  POST /api/register-relay    - 注册中继服务器")
    logging.info("  POST /api/heartbeat         - 发送心跳")
    logging.info("  POST /api/unregister-relay  - 注销中继服务器")
    logging.info("  GET  /api/best-server       - 获取最佳服务器")
    logging.info("  GET  /health                - 健康检查")
    logging.info("=" * 60)
    
    app = create_app()
    
    # 启动清理任务
    loop = asyncio.get_event_loop()
    loop.create_task(cleanup_task())
    
    # 启动 Web 服务器
    web.run_app(app, host=TRACKER_HOST, port=TRACKER_PORT)

if __name__ == "__main__":
    main()
